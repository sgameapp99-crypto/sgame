<!DOCTYPE html>
<html lang="zh-Hant">
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&family=Teko:wght@300..700&display=swap" rel="stylesheet">
        <meta name="google" content="notranslate" />
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="format-detection" content="telephone=no">
        <meta name="hostname" content="webServer6">
                                    <meta name="keywords" content="台灣運彩,討論區,賽事討論,運動討論,運動彩券討論,運彩討論,運彩分析,運動分析,運動彩券分析,運動彩券,運動彩,運彩,玩運彩,玩韻彩,完運彩,完韻采,運彩朋友圈,賽事預測,美國職棒,日本職棒,中華職棒,NBA,MLB,足球,韓國職棒,墨西哥棒球,韓國女籃,日本職籃,中國職籃,韓國職籃,俄羅斯冰球,美式足球,網球,KBO,KHL,NHL,NPB,CPBL,NFL,WNBA,即時比分" />
<meta name="description" content="台灣運彩迷必上，全台最知名的運動彩券網站，要買台灣運彩，先看玩運彩" />

<meta property="og:type" content="website" />
<meta property="og:image" content="https://www.playsport.cc/includes/images/playsport_square_big.png" />
<meta property="og:site_name" content="玩運彩" />
<meta property="fb:admins" content="100003206578531" />

<link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                        <title>關於我們 - 玩運彩 台灣運動彩券朋友圈</title>
                <!--CSS start-->
                        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="0">
        <meta HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
        <link rel="stylesheet" href="//fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="/build/css/layout/layout-ac772369fd.cdn.css?v=20210809">
        <link rel="stylesheet" href="/build/css/layout/style_route_all-1f16896256.css?v=20210809" type="text/css" media="screen"/>
        <link rel="stylesheet" href="/build/css/layout/footerbox-28981caad0.web.css?v=20210809" type="text/css" media="screen"/>
        <!-- ==================== #8380 加大手機版footer ==================== -->
                <!-- ==================== #8380 加大手機版footer end ==================== -->

        <link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                <!--[if lt IE 7]><link rel="stylesheet" href="/CSS/style_ltIE7.css" type="text/css" media="screen" />
        <![endif]-->
        <!--[if IE 7]><link rel="stylesheet" href="/CSS/style_IE7.css" type="text/css" media="screen" /><![endif]-->
        <!--[if IE 8]><link rel="stylesheet" href="/CSS/style_IE8.css" type="text/css" media="screen" /><![endif]-->
        <!--CSS end-->
                <script type="text/javascript" src="/cdn/jquery/jquery-1.11.1.min.js?v=20210809"></script>
                            <!-- all css set in controller -->
                        <link href="/build/css/aboutus/aboutus-2174c0e04f.css?v=20210809" rel="stylesheet" type="text/css" />
                                                            <script type="text/javascript" src="/build/js/layout/layout-eeed8409c8.cdn.js?v=20210809"></script>
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-C8806X8QRW"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
                                                                        gtag('config', 'G-C8806X8QRW', {
                            'content_group': '關於我們'
                        });
                                                        </script>
                    <script>
                (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                ga('create', 'UA-6819717-3', 'auto');
                ga('require', 'displayfeatures');
            </script>
                <script type="text/javascript">
            var newMobile=false;
        </script>
        <script src="/build/js/layout-e2d4248546.js?v=20210809"></script>
        <script type="text/javascript">
                    </script>
    </head>
    <body id="playsportcc-aboutus-id" class="playsportcc-index">
                <div id="rootbox-id" class="rootbox">
                        <div class="headerbox">
                <div class="headerboxin">
                    <!-- header menu start -->
                    <div id="smoothmenu1" class="ddsmoothmenu">

    <!-- ================== #8379 移除header所有次選單過場效果 ======================== -->
    <!-- 添加 純css下拉用class="drop-down-menu" -->
    <ul class="drop-down-menu">
                                <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item js-header-menu--guess" href="/guess?from=header"><span></span>玩競猜</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link js-header-menu--guess"   href="/guess?from=header">遊戲區</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/predict/games?allianceid=1&type=p&from=header"><span></span>預測賽事</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/games?allianceid=1&from=header">預測賽事</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/scale?allianceid=1&from=header">觀看預測比例</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/forum?from=header"><span></span>討論區</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/forum?from=header">運彩版</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/buyPredict/medalFire/1?from=header"><span></span>找高手</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/medalFire/1?ck=1&from=header">莊家殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/singleKiller/1?ck=2&from=header">單場殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/winRate?allianceid=1&from=header">勝率榜</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/mainPrediction?allianceid=1&from=header">主推榜</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/livescore/1?from=header"><span></span>即時比分</a>
                                <ul>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/gamesData/battle?allianceid=1&from=header"><span></span>看數據</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/battle?allianceid=1&from=header">對戰資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/teams?allianceid=1&from=header">球隊資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/standings/3?from=header">戰績排名</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/result?allianceid=1">賽事結果查詢</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/member/search"><span></span>玩家搜尋</a>
                            </li>
                        </ul>
    <br style="clear: left" />
</div>

<style>
        #menu-limited img ,#menu-prizeDraw img{ width:70px; margin-top:4px;}
    </style>

                    <!-- header menu end -->
                    <div id="navi" class="default">
                        <div class="fixedpos" id="fixedposid">
                                                            <ul id="functionbarid" class="functionbar">
    <li class="loginitem"><a id="headerLoginButton" class="headerLoginButton cboxElement tween" href="/member/login"><i class="material-icons md-small">&#xE897;</i>登入</a></li>
    <li class="signupitem"><a href="/member/register" class="tween"><i class="material-icons md-small">&#xE7FE;</i>加入會員</a></li>
</ul>
<script type="text/javascript" src="/includes/js/global.js?v=20210809"></script>
<style>
.loginLightbox #cboxContent, .loginLightbox #cboxLoadedContent {
    border: 0;
    background: none;
    color: #000;
}
</style>
<script>
$(function() {
    var notLoginJsonData = {"isMobile":false};
    if (notLoginJsonData.isMobile) {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            location.href = '/member/login';
        });
    } else {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            var redirectUrl = $(this).data('redirecturl');
            $('a.headerLoginButton').colorbox({
                href:"/member/login",
                width: 386,
                height: 634, //登入按鈕x2：542
                className: 'loginLightbox',
                onComplete: function() {
                    $('#login-panel input[name="redirectUrl"]').val(redirectUrl);
                    $('.loginLightbox .ui-dialog-titlebar-close').click(function(event) {
                        $.colorbox.close()
                    });
                    // $(this).colorbox.resize();
                }
            });
        });
    }
})
</script>
                                                     </div>
                    </div>
                    <!-- logo start -->
                    <style type="text/css">.logobox-headerTheme {display: none;}</style>
                                        <div class="logobox">
                        <a href="/forum?redirect_from=headerLogo" target="_top">
                            <img src="/images/logo.png" alt="玩運彩" border="0" width="140" height="57">
                        </a>
                    </div>
                                        <!-- logo end -->

                    <script src="/includes/js/nagging-menu.js?v=20210809"></script>

                    <script type="text/javascript">
                    $(function() {
                        $("body").click(function(event) {
                            if(event.target.id == 'navi'){
                                $.scrollTo(0, 500);
                            }
                        });
                    });
                    </script>
                </div>
            </div>
                        <div class="contentbox">
                                                <div class="winnermarkmask ">
                    <ul class="winnermark ">
                                                <li>
                            <a  id="winnerurl-0" href="https://www.playsport.cc/app_campaign.php?" onmouseover="winnercolor('0','set');" onmouseout="winnercolor('0','unset');">
                                <span class="winnerid" id="winnerid-0">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    秒秒更新！超快即時比分，立刻下載                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-1" href="https://apps.apple.com/app/apple-store/id730277109?pt=1952181&ct=web_head3title_defaultTitle&mt=8" onmouseover="winnercolor('1','set');" onmouseout="winnercolor('1','unset');">
                                <span class="winnerid" id="winnerid-1">
                                                                    </span>
                                <span class="gametype">
                                    討論區                                </span>
                                    APP訊息推播超方便，再也不用重整了！                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-2" href="https://www.playsport.cc/single_killer_rank.php?alliance=3" onmouseover="winnercolor('2','set');" onmouseout="winnercolor('2','unset');">
                                <span class="winnerid" id="winnerid-2">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    ☆☆☆第179期單場殺手出爐☆☆☆                            </a>
                        </li>
                                            </ul>
                </div>
                                <div class="mainconbox">
                    <div class="mainconboxin mainconboxinwide ">
                                                                    
<div class="common-box aboutus-box">
    <div class="common-tabs aboutus-tabs">
        <ul class="tabs">
            <li><a href="#tab1">簡介</a><span></span></li>
            <li><a href="#tab2">大事紀</a><span></span></li>
        </ul>

        <div class="tab_container">
            <!--Tab 1 ==== 簡介 ====-->
            <div id="tab1" class="tab_content">
                <div class="common-article-box">
                    <img class="aboutus_trademark" src="images/Trademark_one.jpg">

                    <p>玩運彩以「分享很簡單、中獎不孤單」的初衷，於2009年2月24日創立，是一個聚集運動賽事和運動彩券喜好者的社群平台。</p>
                    <br>
                    <p>玩運彩是目前運動彩券業內最大的社群網站，主要的服務提供－</p>
                    <p class="text_indentoff">［<a href="https://www.playsport.cc/forum" target="_blank">論壇交流</a>］輸球想賭爛？贏球想分享？想分析球賽？都來～</p>
                    <p class="text_indentoff">［<a href="https://www.playsport.cc/livescore/1" target="_blank">即時比分</a>］彩迷最愛的每秒更新、全中文最快即時比分</p>
                    <p class="text_indentoff">［<a href="https://www.playsport.cc/buyPredict/medalFire/1" target="_blank">販售預測</a>］百元有找，購買預測參考下注，當上殺手可得45%分潤</p>
                    <p class="text_indentoff">［<a href="https://www.playsport.cc/predict/games?allianceid=1&type=p" target="_blank">預測賽事</a>］預測看好的過關隊伍，紀錄戰績，還有機會當上殺手賺分潤</p>
                    <br>
                    <p>
                        「滿足使用者需求」是我們開發網站功能的唯一準則，嚴謹的產品開發流程、使用者經驗訪談、以數據導向來做決策，再配合多螢需求來設計使用介面，我們最大的目標是滿足彩迷們的需求，讓彩迷每天都離不開我們的網站和APP。
                    </p>
                    <br>
                    <p>
                        玩運彩每年流量、獲利穩定成長，並名列similarweb台灣體育類網站第一名。 我們也推出了「即時比分APP」、「討論區APP」，網站和 APP 每月平均有 3 億瀏覽量，每月使用人數約 100 萬人。
                    </p>
                    <br>
                    <p>
                        我們的瞎七八怪文化－<br>
                        「玩運彩」是一個年輕的團隊，「work hard, play hard」是我們的工作哲學。<br>
                        我們盡可能減少限制，採高度自我管理，我們專心工作、輕鬆上班。<br>
                    </p>
                    <p class="text_indentfo">。只要認真工作，獎金福利大方給</p>
                    <p class="text_indentfo">。彈性上下班時間，早點來就早點走，不必打卡</p>
                    <p class="text_indentfo">。在辦公室不必穿著制式彆扭的服裝，短褲拖鞋是我們最常見的搭配</p>
                    <p class="text_indentfo">。提供吃不完、喝不完的飲料零食，中午還可以在沙發躺平爽睡</p>
                    <p class="text_indentfo">。辦公環境舒服，同事相處氣氛融洽</p>
                    <p class="text_indentfo">。工作效率高、好溝通，不必忍受跟豬隊友共事</p>
                    <p class="text_indentfo">。每月有Happy Hours玩樂時間、每年員工旅遊</p>
                    <p class="text_indentfo">。太多了講不完，其他更多請您一定要看：<a href="https://www.facebook.com/playsportoffice?ref=bookmarks" target="_blank">玩運彩辦公室</a></p>
                    <p class="text_indentfo">有興趣加入玩運彩嗎？<a href="https://www.104.com.tw/jobbank/custjob/index.php?r=cust&j=5e4a446d445c3e675a583a1d1d1d1d5f2443a363189j01" target="_blank">歡迎到104查看職缺</a></p>
                    <br>
                </div>

                <!-- 20170623 媒體報導 start -->
                <a name="news"></a>
                <div class="common-article-box newsmore_content">
                    <h1 class="about-teamhone">想更深入的了解玩運彩？您可以看看這些媒體報導</h1>
                    <div class="aboutus-article-section aboutus-article-section-news">
                        <h2>玩運彩的新聞報導</h2>
                        <ul>
                            <li>
                                <strong>2015/04/23<span>經濟部</span></strong>
                                <a href="http://vsip.tycg.gov.tw/information_90_15799.html" target="_blank">通過經濟部核可，玩運彩進駐高雄軟體科學園區</a>
                            </li>
                            <li>
                                <strong>2009/11/19<span>中央社</span></strong>
                                <a href="http://www.cna.com.tw/postwrite/Detail/43743.aspx#.WVsFgdOGNTZ">失業男孩愛棒球，創造運彩神準預測網站</a>
                            </li>
                            <li>
                                <strong>2009/11/19<span>聯合報</span></strong>
                                <p>大男生玩運彩 創業夢成真</p>
                            </li>
                        </ul>
                    </div>
                    <div class="aboutus-article-section">
                        <h2>網站、部落客報導</h2>
                        <ul>
                            <li>
                                <strong>2017/05/26<span></span></strong>
                                <a href="https://www.facebook.com/STalkTW/posts/1277042455750258" target="_blank">玩運彩執行長-吳憲達 受邀至創業台槓演講</a>
                            </li>
                            <li>
                                <strong>2015/08/25<span></span></strong>
                                <a href="https://hpx.tw/archives/20824" target="_blank">玩運彩執行長-吳憲達 受邀至悠識 HPX演講</a>
                            </li>
                            <li>
                                <strong>2012/04/18<span></span></strong>
                                <a href="https://www.youtube.com/watch?v=PmJa5raXwZU" target="_blank">玩運彩執行長-吳憲達 受邀至數位時待演講</a>
                            </li>
                        </ul>
                    </div>
                </div> 

                <div class="common-article-box newsmore_content newsmore_contents js-newsmore">              
                    <div class="aboutus-article-section aboutus-article-section-news">
                        <ul>
                                                            <li>
                                    <strong>2009/10/26<span>台視</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=s9f0lcVqmnU" target="_blank">他們最準! 預測運彩網站暴紅</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>華視</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=ufoCbKYu4Lg" target="_blank">失業生架網站 預測運彩吸人氣</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>民視</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=wJ4TtpLSXl0" target="_blank">運彩網站竄紅 年輕創業夢成真</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>中視</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=nNIHqDwgmoI" target="_blank">3男創業架運彩網 預測精準受歡迎</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>東森</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=YZSY3kIH0_8" target="_blank">準確度高 運彩預測網站爆紅</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>年代</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=IjkYqBt78OI" target="_blank">男大生網路創業圓夢 運彩預測爆紅</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/10/26<span>非凡</span></strong>
                                                                            <a href="http://www.youtube.com/watch?v=teD2dqhMesc" target="_blank">畢業生失業架網站 預測運彩吸人氣</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/08/30<span>公民新聞平</span></strong>
                                                                            <a href="http://www.peopo.org/portal.php?op=viewPost&articleId=41836" target="_blank">網站黏性超越無名小站、巴哈姆特的新創網站-玩運彩</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/08/25<span>Yahoo!奇摩</span></strong>
                                                                            <p>資策會idea show秀創意　32團隊展出web2.0新應用</p>
                                                                    </li>
                                                            <li>
                                    <strong>2009/08/11<span>Yahoo!奇摩</span></strong>
                                                                            <p>玩運彩 看看誰是神準預測王</p>
                                                                    </li>
                                                    </ul>
                    </div>
                    <div class="aboutus-article-section">
                        <ul>
                                                            <li>
                                    <strong>2012/02/15<span>數位時代</span></strong>
                                                                            <a href="https://www.bnext.com.tw/article/22120/BN-ARTICLE-22120" target="_blank">運動彩券賽事預測社群分享網站「玩運彩」</a>
                                                                    </li>
                                                            <li>
                                    <strong>2011/10/20<span>理財周刊</span></strong>
                                                                            <p>7年級生創全台唯一運彩論壇網站 年收千萬</p>
                                                                    </li>
                                                            <li>
                                    <strong>2011/09/06<span>Inside</span></strong>
                                                                            <a href="http://www.inside.com.tw/2011/09/06/next-boom" target="_blank">案例剖析 玩運彩的下一個成長</a>
                                                                    </li>
                                                            <li>
                                    <strong>2011/09/05<span>Inside</span></strong>
                                                                            <a href="http://www.inside.com.tw/2011/09/05/playsport" target="_blank">專訪 玩運彩創辦人 -吳憲達</a>
                                                                    </li>
                                                            <li>
                                    <strong>2011/08/06<span>Inside</span></strong>
                                                                            <a href="http://www.inside.com.tw/2011/08/06/playsport-offic" target="_blank">【辦公室系列文】運動彩券社群網站「玩運彩」</a>
                                                                    </li>
                                                            <li>
                                    <strong>2010/03/06<span>Mr.6</span></strong>
                                                                            <a href="http://mr6.cc/?p=4185" target="_blank">運彩分析師的星光舞台-玩運彩</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/12/03<span>香港矽谷</span></strong>
                                                                            <a href="http://www.hksilicon.com/kb/articles/3647/1/-/Page1.html" target="_blank">讓運動彩券成為投資的網站-玩運彩</a>
                                                                    </li>
                                                            <li>
                                    <strong>2009/03/01<span>凱文的網路創業觀察</span></strong>
                                                                            <a href="http://webman.pixnet.net/blog/post/23378815" target="_blank">運動達人兼具準確的預測眼光 – 玩運彩網站</a>
                                                                    </li>
                                                    </ul>
                    </div>
                </div>
                <script type="text/javascript">
                    function newsMore(){
                        $(".js-newsmore").slideToggle("fast");
                        $(".js-newsmore_arrow").toggleClass("reportActive");
                    } 
                </script>  
                <div class="newsmore_arrow js-newsmore_arrow" onclick="newsMore(); return false;">
                    <strong class="arrow_bottom">看更多</strong>
                    <span class="arrow_top">收合</span>
                </div>
                <!-- 20170623 媒體報導 end -->

                <br>
                <br>
                <div class="common-article-box">
                    <h1 class="about-teamhone">玩運彩團隊</h1>
                    <!--<img src="images/logo_aboutus.png" alt="玩運彩logo" class="img-logo"/>-->
                    <!-- 20170623 團隊介紹 start -->
                    <br />
                                            <div class="about-team about-team--ceo">
                            <div class="about-team__photo">
                                <img src="images/aboutus/01sam.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">執行長</div>
                                <ul class="job_skill">
                                                                            <li>透過UX Design，做出使用者喜愛的產品</li>
                                                                            <li>服務、照顧員工，讓員工保持向心力</li>
                                                                            <li>強迫自己思考，想辦法找出自己和團隊的缺點</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>激怒員工</li>
                                                                            <li>開黃腔</li>
                                                                            <li>精通各國語言腔</li>
                                                                            <li>染各種顏色頭髮</li>
                                                                            <li>自我感覺良好</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team about-team__photo--sara">
                            <div class="about-team__photo">
                                <img src="images/aboutus/02sara.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">董事長</div>
                                <ul class="job_skill">
                                                                            <li>財務管理</li>
                                                                            <li>使用者訪談</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>帶小孩</li>
                                                                            <li>聽不懂黃色笑話</li>
                                                                            <li>炒熱氣氛</li>
                                                                            <li>專業鳥語博士</li>
                                                                            <li>創造新成語</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team about-team--ceo">
                            <div class="about-team__photo">
                                <img src="images/aboutus/03paulean.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">工程主管</div>
                                <ul class="job_skill">
                                                                            <li>iOS APP</li>
                                                                            <li>Web Backend</li>
                                                                            <li>Linux Server And Performance Tuning</li>
                                                                            <li>工程危機處理與決策</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>美食照騙攝影</li>
                                                                            <li>專門推坑保養品</li>
                                                                            <li>打執行長維持正義</li>
                                                                            <li>信用卡推銷</li>
                                                                            <li>寫模擬市民外掛賺錢</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/04neo.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">工程師</div>
                                <ul class="job_skill">
                                                                            <li>Android APP</li>
                                                                            <li>Web Backend</li>
                                                                            <li>Linux Server And Performance Tuning</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>騎小折環島</li>
                                                                            <li>單車一日台中高雄</li>
                                                                            <li>木工 DIY</li>
                                                                            <li>支持兄弟象超過26年</li>
                                                                            <li>一秒變少女</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/05james.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">工程師</div>
                                <ul class="job_skill">
                                                                            <li>Web Backend</li>
                                                                            <li>Linux Server And Performance Tuning</li>
                                                                            <li>Hacking</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>美劇研究</li>
                                                                            <li>長期吃難吃的便當</li>
                                                                            <li>信用卡系-精通各種信用卡回饋</li>
                                                                            <li>嘉義飛魚</li>
                                                                            <li>比酸民還酸</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/14bro.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">工程師</div>
                                <ul class="job_skill">
                                                                            <li>Web Backend</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>新鮮的肝，不愛睡覺</li>
                                                                            <li>午休時間看美劇</li>
                                                                            <li>桌遊達人</li>
                                                                            <li>驚悚電影達人</li>
                                                                            <li>用13吋Macbook寫程式，dock還超大</li>
                                                                            <li>在高雄坐公車上下班的男人</li>
                                                                            <li>把九宮格變成三宮格</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/16lynn.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">工程師</div>
                                <ul class="job_skill">
                                                                            <li>iOS APP</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>瀟灑帥女子</li>
                                                                            <li>獨自去荒山野嶺的地方也不害怕</li>
                                                                            <li>去祕魯自助旅行</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/06saky.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">設計主管</div>
                                <ul class="job_skill">
                                                                            <li>平面設計</li>
                                                                            <li>UI/UX</li>
                                                                            <li>設計流程與方法</li>
                                                                            <li>設計評論</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>影劇評論</li>
                                                                            <li>體位技研</li>
                                                                            <li>冷面笑匠</li>
                                                                            <li>看房子</li>
                                                                            <li>拼混酒</li>
                                                                            <li>法務</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/07seven.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">設計師</div>
                                <ul class="job_skill">
                                                                            <li>介面設計</li>
                                                                            <li>網頁設計</li>
                                                                            <li>插圖</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>美食評論家</li>
                                                                            <li>早餐連續吃肉包八個月</li>
                                                                            <li>模型專家</li>
                                                                            <li>句點王</li>
                                                                            <li>冒冷汗</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/08winnie.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">社群主管</div>
                                <ul class="job_skill">
                                                                            <li>網站營運管理</li>
                                                                            <li>社群事務統籌規畫</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>小套房煮菜</li>
                                                                            <li>苗條健人</li>
                                                                            <li>香菇栽種技研</li>
                                                                            <li>精通綜藝梗</li>
                                                                            <li>嘴砲執行長</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/15fly.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">社群人員</div>
                                <ul class="job_skill">
                                                                            <li>網站營運管理</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>參加團購</li>
                                                                            <li>天天半夜起床照顧小孩</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/17annie.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">社群人員</div>
                                <ul class="job_skill">
                                                                            <li>網站營運管理</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>吃乾麵達人</li>
                                                                            <li>天然ㄟ尚好的娃娃音</li>
                                                                            <li>牡羊ㄎㄧㄤ</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/18deer.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">社群人員</div>
                                <ul class="job_skill">
                                                                            <li>網站營運管理</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>超會聊天，話超多</li>
                                                                            <li>根本防疫指揮中心工作人員來著</li>
                                                                            <li>翻白眼達人</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/11helene.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">產品人員</div>
                                <ul class="job_skill">
                                                                            <li>網站營運管理</li>
                                                                            <li>UX 產品設計</li>
                                                                            <li>產品測試</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>買衣服買到房間放不下</li>
                                                                            <li>擁有上百雙鞋</li>
                                                                            <li>尾牙抽好獎但是都不用</li>
                                                                            <li>吃垃圾食物不會胖</li>
                                                                            <li>累積的廚餘已經比阿里山高</li>
                                                                    </ul>
                            </div>
                        </div>
                                            <div class="about-team ">
                            <div class="about-team__photo">
                                <img src="images/aboutus/12eddy.png">
                            </div>
                            <div class="about-team__content">
                                <div class="job_title">數據分析</div>
                                <ul class="job_skill">
                                                                            <li>R</li>
                                                                            <li>python</li>
                                                                            <li>SQL</li>
                                                                            <li>data mining</li>
                                                                            <li>統計預測模型</li>
                                                                    </ul>
                                <ul class="job_skillno skill--color">
                                                                            <li>專精烘培</li>
                                                                            <li>精通各種網路購物平台</li>
                                                                            <li>愛看電競直播但不玩</li>
                                                                            <li>跑馬拉松-人體空氣清淨機</li>
                                                                            <li>專業訂飲料</li>
                                                                    </ul>
                            </div>
                        </div>
                                        <!-- 20170623 團隊介紹 end -->
                </div>

                <div class="common-article-box">
                    <h1>玩運彩聲明</h1>
                    <ul class="common-liststyle">
                        <li>嚴禁任何地下賭盤推銷行為</li>
                        <li>投注地下賭盤為非法行為，請勿以身試法</li>
                        <li>請勿過度投注，並做好自身賭金管理</li>
                        <li>本站杜絕任何非法行為的合作關係</li>
                    </ul>
                </div>
            </div><!--tab1-->

            <!--Tab 2 ==== 大事記 ====-->
            <div id="tab2" class="tab_content">
                <div id="timeline">
                    <ul id="dates">
                                                                            <li>
                                <a href="#201310" class="selected">
                                    2025.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2024.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2023.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2023.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2022.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2021.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2020.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2019.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2019.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2019.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2019.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2019.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2018.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2017.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2017.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2017.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2017.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2016.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2015.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2015.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2014.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2013.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2012.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.05                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2011.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.06                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2010.01                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.12                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.09                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.08                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.07                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.04                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.03                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2009.02                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2008.11                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2008.10                                </a>
                            </li>
                                                    <li>
                                <a href="#201310" >
                                    2008.08                                </a>
                            </li>
                                            </ul>
                    <ul id="issues">
                                                                                                        <li id="202506" class="selected">
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202506.jpg?v=202506"  />
                                    <p>新版手機即時比分上線</p>
                                </div>
                                
                            </li>
                                                                                <li id="202410" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202410.jpg?v=202506"  />
                                    <p>即時比分優化NBA傷兵名單－新增更新時間、傷勢部位、最快上場時間</p>
                                </div>
                                
                            </li>
                                                                                <li id="202312" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202312.jpg?v=202506"  />
                                    <p>新增戰績頁</p>
                                </div>
                                
                            </li>
                                                                                <li id="202308" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202308.jpg?v=202506"  />
                                    <p>新增網頁、手機版足球即時比分</p>
                                </div>
                                
                            </li>
                                                                                <li id="202212" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202212.jpg?v=202506"  />
                                    <p>玩競猜國際籃賽新增火箭籃球聯盟遊戲</p>
                                </div>
                                                                    <div><p>即時比分新增NBA預定先發名單</p></div>
                                                                    <div><p>即時比分APP新增T1</p></div>
                                
                            </li>
                                                                                <li id="202211" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202211.jpg?v=202506"  />
                                    <p>玩競猜南非賽馬新增3.5 及 5.5大小遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202210" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202210.jpg?v=202506"  />
                                    <p>玩競猜新增mlb、nba、韓籃主客大小遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202208" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202208.jpg?v=202506"  />
                                    <p>即時比分新增中職及美棒先發打線</p>
                                </div>
                                
                            </li>
                                                                                <li id="202207" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202207.jpg?v=202506"  />
                                    <p>即時比分新增日棒先發打線</p>
                                </div>
                                
                            </li>
                                                                                <li id="202205" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202205.jpg?v=202506"  />
                                    <p>即時比分 - 新增投手被安打、四壞、三振數據</p>
                                </div>
                                                                    <div><p>玩競猜開放澳洲賽馬勝出馬遊戲</p></div>
                                
                            </li>
                                                                                <li id="202203" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202203.jpg?v=202506"  />
                                    <p>即時比分 - 新增「命中 / 投球」數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="202201" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202201.jpg?v=202506"  />
                                    <p>即時比分新增中國職籃比賽過程、傷兵名單</p>
                                </div>
                                
                            </li>
                                                                                <li id="202112" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202112.jpg?v=202506"  />
                                    <p>玩競猜新增澳洲賽馬遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202110" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202110.jpg?v=202506"  />
                                    <p>玩競猜國際籃賽新增義甲籃球</p>
                                </div>
                                
                            </li>
                                                                                <li id="202108" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202108.jpg?v=202506"  />
                                    <p>玩競猜新增南非賽馬遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202107" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202107.jpg?v=202506"  />
                                    <p>新增手機版即時比分</p>
                                </div>
                                
                            </li>
                                                                                <li id="202106" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202106.jpg?v=202506"  />
                                    <p>即時比分新增韓國職棒比賽過程、團隊打擊</p>
                                </div>
                                
                            </li>
                                                                                <li id="202102" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202102.jpg?v=202506"  />
                                    <p>玩競猜開放澳洲職籃</p>
                                </div>
                                                                    <div><p>玩競猜開放網球走地遊戲</p></div>
                                
                            </li>
                                                                                <li id="202101" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202101.jpg?v=202506"  />
                                    <p>網頁版即時比分新增排球、P+聯盟</p>
                                </div>
                                                                    <div><p>玩競猜開放韓國男子排球V聯賽</p></div>
                                                                    <div><p>玩競猜開放韓國賽馬</p></div>
                                                                    <div><p>玩競猜國際籃賽開放希臘A1</p></div>
                                
                            </li>
                                                                                <li id="202012" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202012.jpg?v=202506"  />
                                    <p>玩競猜新增紐西蘭賽馬遊戲</p>
                                </div>
                                                                    <div><p>國際籃賽新增"土耳其超級籃球聯賽"及"VTB聯賽"全場遊戲囉</p></div>
                                
                            </li>
                                                                                <li id="202010" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202010.jpg?v=202506"  />
                                    <p>玩競猜新增電競籃球遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202009" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202009.jpg?v=202506"  />
                                    <p>新增網頁版網球、美足即時比分</p>
                                </div>
                                                                    <div><p>國際籃賽新增"西甲籃球"全場遊戲囉</p></div>
                                                                    <div><p>玩競猜開放美式足球賽前遊戲</p></div>
                                
                            </li>
                                                                                <li id="202007" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202007.jpg?v=202506"  />
                                    <p>玩競猜開放紐西蘭聯賽、以色列聯賽及WNBA全場遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202006" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202006.jpg?v=202506"  />
                                    <p>玩競猜開放德甲聯賽全場遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202005" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202005.jpg?v=202506"  />
                                    <p>WSBL網頁版即時比分上線</p>
                                </div>
                                
                            </li>
                                                                                <li id="202004" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202004.jpg?v=202506"  />
                                    <p>玩競猜開放韓棒走地遊戲</p>
                                </div>
                                                                    <div><p>玩競猜新增乒乓球、網球遊戲</p></div>
                                                                    <div><p>乒乓球網頁版即時比分</p></div>
                                
                            </li>
                                                                                <li id="202003" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202003.jpg?v=202506"  />
                                    <p>玩競猜開放MLB 、中職走地遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="202002" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202002.jpg?v=202506"  />
                                    <p>俄羅斯冰球網頁版即時比分上線</p>
                                </div>
                                                                    <div><p>玩競猜開放俄羅斯冰球走地遊戲</p></div>
                                
                            </li>
                                                                                <li id="202001" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/202001.jpg?v=202506"  />
                                    <p>玩競猜開放NHL、日籃、歐籃、ABL走地遊戲</p>
                                </div>
                                                                    <div><p>平均年終首次突破12個月</p></div>
                                
                            </li>
                                                                                <li id="201912" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201912.jpg?v=202506"  />
                                    <p>玩競猜開放NBA、中籃、韓籃走地遊戲</p>
                                </div>
                                
                            </li>
                                                                                <li id="201911" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201911.jpg?v=202506"  />
                                    <p>ABL即時比分上線囉</p>
                                </div>
                                
                            </li>
                                                                                <li id="201908" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201908.jpg?v=202506"  />
                                    <p>即時比分新增WNBA團隊數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="201907" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201907.jpg?v=202506"  />
                                    <p>即時比分APP榮登iOS及Android運動類排行榜第一名</p>
                                </div>
                                                                    <div><p>即時比分新增棒球先發投手日夜場數據</p></div>
                                
                            </li>
                                                                                <li id="201901" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201901.jpg?v=202506"  />
                                    <p>即時比分網頁版新增日籃、韓籃比賽過程</p>
                                </div>
                                
                            </li>
                                                                                <li id="201812" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201812.jpg?v=202506"  />
                                    <p>即時比分網頁版新增中、日、韓籃團隊數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="201809" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201809.jpg?v=202506"  />
                                    <p>即時比分新增韓棒投打數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="201807" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201807.jpg?v=202506"  />
                                    <p>Alexa 台灣排名第46名</p>
                                </div>
                                                                    <div><p>討論區與即時比分APP榮登iOS運動類第一、二名 / Android第一、三名</p></div>
                                                                    <div><p>新增投手整季逐場出賽紀錄</p></div>
                                                                    <div><p>新增WNBA即時比分</p></div>
                                                                    <div><p>即時比分新增MLB、日棒投打近三年對戰成績</p></div>
                                
                            </li>
                                                                                <li id="201806" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201806.jpg?v=202506"  />
                                    <p>即時比分棒球數據新增面對先發左/右投勝敗</p>
                                </div>
                                                                    <div><p>Alexa台灣網站排名-第56名</p></div>
                                
                            </li>
                                                                                <li id="201805" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201805.jpg?v=202506"  />
                                    <p>玩競猜上線</p>
                                </div>
                                                                    <div><p>Alexa台灣網站排名-第60名</p></div>
                                                                    <div><p>iOS討論區新版APP上線</p></div>
                                                                    <div><p>日棒比賽過程上線</p></div>
                                
                            </li>
                                                                                <li id="201804" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201804.jpg?v=202506"  />
                                    <p>Android討論區新版APP上線囉</p>
                                </div>
                                
                            </li>
                                                                                <li id="201711" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201711.jpg?v=202506"  />
                                    <p>澳棒即時比分網頁版與APP上線</p>
                                </div>
                                
                            </li>
                                                                                <li id="201709" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201709.jpg?v=202506"  />
                                    <p>即時比分網頁版新增棒球(MLB、日、中)團隊打擊數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="201708" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201708.jpg?v=202506"  />
                                    <p>即時比分網頁版與APP新增棒球先發投手逐場出賽紀錄</p>
                                </div>
                                
                            </li>
                                                                                <li id="201707" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201707.jpg?v=202506"  />
                                    <p>榮獲電子發票績優營業人獎</p>
                                </div>
                                
                            </li>
                                                                                <li id="201612" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201612.jpg?v=202506"  />
                                    <p>生活版討論區上線</p>
                                </div>
                                
                            </li>
                                                                                <li id="201611" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201611.jpg?v=202506"  />
                                    <p>SBL即時比分網頁版與APP上線</p>
                                </div>
                                
                            </li>
                                                                                <li id="201610" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201610.jpg?v=202506"  />
                                    <p>推出-殺手勳章上線</p>
                                </div>
                                                                    <div><p>奧創殺手上線</p></div>
                                                                    <div><p>網頁版歐洲職籃即時比分上線</p></div>
                                
                            </li>
                                                                                <li id="201608" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201608.jpg?v=202506"  />
                                    <p>Alexa台灣網站排名－第47名</p>
                                </div>
                                                                    <div><p>推出-殺手報牌App</p></div>
                                
                            </li>
                                                                                <li id="201607" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201607.jpg?v=202506"  />
                                    <p>玩運彩投放中華職棒電視廣告</p>
                                </div>
                                
                            </li>
                                                                                <li id="201606" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201606.jpg?v=202506"  />
                                    <p>ios即時比分新增賽事紀錄</p>
                                </div>
                                                                    <div><p>手機版預測比例頁面改版</p></div>
                                
                            </li>
                                                                                <li id="201605" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201605.jpg?v=202506"  />
                                    <p>即時比分網頁版與APP新增棒球先發投手數據</p>
                                </div>
                                
                            </li>
                                                                                <li id="201512" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201512.jpg?v=202506"  />
                                    <p>玩運彩換辦公室囉！</p>
                                </div>
                                
                            </li>
                                                                                <li id="201501" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201501.jpg?v=202506"  />
                                    <p>新版殺手金牌上線</p>
                                </div>
                                                                    <div><p>NBA即時比分速度再進化</p></div>
                                
                            </li>
                                                                                <li id="201411" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201411.jpg?v=202506"  />
                                    <p>網頁版中國職籃即時比分上線</p>
                                </div>
                                                                    <div><p>新版玩家搜尋上線</p></div>
                                
                            </li>
                                                                                <li id="201410" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201410.jpg?v=202506"  />
                                    <p>網頁版日本職籃即時比分上線</p>
                                </div>
                                                                    <div><p>討論區貼圖上線</p></div>
                                
                            </li>
                                                                                <li id="201406" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201406.jpg?v=202506"  />
                                    <p>ios即時比分新增中華職棒與韓國職棒</p>
                                </div>
                                                                    <div><p>android即時比分新增韓國職棒</p></div>
                                
                            </li>
                                                                                <li id="201405" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201405.jpg?v=202506"  />
                                    <p>網站首頁改版</p>
                                </div>
                                                                    <div><p>網頁版韓國職棒即時比分上線</p></div>
                                
                            </li>
                                                                                <li id="201404" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201404.jpg?v=202506"  />
                                    <p>中華職棒即時比分網頁版與APP(android)上線</p>
                                </div>
                                                                    <div><p>玩運彩團隊第二次挑戰從高雄騎腳踏車到墾丁成功 </p></div>
                                
                            </li>
                                                                                <li id="201403" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201403.jpg?v=202506"  />
                                    <p>即時比分2秒更新，速度UP</p>
                                </div>
                                
                            </li>
                                                                                <li id="201402" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201402.jpg?v=202506"  />
                                    <p>新增網球國際盤預測</p>
                                </div>
                                
                            </li>
                                                                                <li id="201401" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201401.jpg?v=202506"  />
                                    <p>台灣運彩接手，北富盤全面改標示為運彩盤</p>
                                </div>
                                
                            </li>
                                                                                <li id="201310" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201310.jpg?v=202506"  />
                                    <p>主機搬家大成功，網站更順暢穩定</p>
                                </div>
                                                                    <div><p>玩運彩討論區APP IOS系統上架</p></div>
                                
                            </li>
                                                                                <li id="201309" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201309.jpg?v=202506"  />
                                    <p>玩運彩討論區APP Android系統上架</p>
                                </div>
                                                                    <div><p>玩運彩團隊挑戰泳渡日月潭成功 </p></div>
                                
                            </li>
                                                                                <li id="201308" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201308.jpg?v=202506"  />
                                    <p>玩運彩做公益 - <a href="http://playworker.pixnet.net/blog/post/98265083" target="new">招待淨覺育幼院小朋友看球賽</a></p>
                                </div>
                                
                            </li>
                                                                                <li id="201307" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201307.jpg?v=202506"  />
                                    <p>賽事數據全面改版，分成「對戰資訊」與「球隊資訊」</p>
                                </div>
                                                                    <div><p>移除銀牌殺手資格</p></div>
                                
                            </li>
                                                                                <li id="201305" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201305.jpg?v=202506"  />
                                    <p>玩運彩做公益 - <a href="http://playworker.pixnet.net/blog/post/96880066" target="new">招待金潭少棒隊看球賽</a></p>
                                </div>
                                                                    <div><p>玩運彩團隊挑戰從高雄騎腳踏車到墾丁成功 </p></div>
                                
                            </li>
                                                                                <li id="201304" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201304.jpg?v=202506"  />
                                    <p>預測賽事系統改版，新增國際盤大小分</p>
                                </div>
                                                                    <div><p>Android新版即時比分APP上架</p></div>
                                
                            </li>
                                                                                <li id="201303" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201303.jpg?v=202506"  />
                                    <p>即時比分APP IOS系統上架</p>
                                </div>
                                
                            </li>
                                                                                <li id="201211" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201211.jpg?v=202506"  />
                                    <p>個人頁大改版，全新頁面上線。</p>
                                </div>
                                                                    <div><p>推出「猜大小分、送大小獎」到波士頓看林書豪打球。</p></div>
                                
                            </li>
                                                                                <li id="201210" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201210.jpg?v=202506"  />
                                    <p>玩運彩第一支手機APP-即時比分上架</p>
                                </div>
                                
                            </li>
                                                                                <li id="201209" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201209.jpg?v=202506"  />
                                    <p>勞資未達協議 NHL封館</p>
                                </div>
                                                                    <div><p>新增都蘭特區</p></div>
                                
                            </li>
                                                                                <li id="201208" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201208.jpg?v=202506"  />
                                    <p>全面移除站內外部廣告</p>
                                </div>
                                
                            </li>
                                                                                <li id="201207" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201207.jpg?v=202506"  />
                                    <p>新增手機板賽事預測功能</p>
                                </div>
                                                                    <div><p>移除銅牌殺手資格</p></div>
                                
                            </li>
                                                                                <li id="201206" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201206.jpg?v=202506"  />
                                    <p>推出北富銀盤口即時比分</p>
                                </div>
                                                                    <div><p>玩運彩粉絲團關閉</p></div>
                                                                    <div><p>台東員工旅遊</p></div>
                                
                            </li>
                                                                                <li id="201205" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201205.jpg?v=202506"  />
                                    <p>日本職棒即時比分上線</p>
                                </div>
                                                                    <div><p>推出獎金高達10萬元的預測活動-10勝10萬爭奪戰</p></div>
                                
                            </li>
                                                                                <li id="201204" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201204.jpg?v=202506"  />
                                    <p>玩運彩網站首頁改版</p>
                                </div>
                                                                    <div><p>流量激增，進行主機升級</p></div>
                                                                    <div><p>際賽事預測系統移除</p></div>
                                
                            </li>
                                                                                <li id="201203" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201203.jpg?v=202506"  />
                                    <p>流量刷新記錄，朝百大邁進了一小步</p>
                                </div>
                                                                    <div><p>賺錢不忘回饋社會，與小港社福單位合作，陪小朋友一起運動</p></div>
                                                                    <div><p>推出看數據功能，讓網站越來越豐富</p></div>
                                
                            </li>
                                                                                <li id="201202" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201202.jpg?v=202506"  />
                                    <p>殺手販售所得全面改為現金分潤</p>
                                </div>
                                                                    <div><p><a href="http://www.moneyweekly.com.tw/Journal/article.aspx?UIDX=13663377520" target="_blank">與理財周刊合作分析林書豪投注法</a></p></div>
                                                                    <div><p><a href="http://www.bnext.com.tw/article/view/cid/157/id/22120" target="_blank">獲得數位時代創業小聚報導</a></p></div>
                                
                            </li>
                                                                                <li id="201112" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201112.jpg?v=202506"  />
                                    <p>NBA封館結束，業績見曙光</p>
                                </div>
                                                                    <div><p>NBA、韓籃即時比分上線服務</p></div>
                                                                    <div><p>同業首例，與國稅局完成協商，殺手所得皆合法報稅</p></div>
                                
                            </li>
                                                                                <li id="201111" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201111.jpg?v=202506"  />
                                    <p>冰球即時比分上線</p>
                                </div>
                                                                    <div><p>墾丁員工旅遊</p></div>
                                
                            </li>
                                                                                <li id="201110" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201110.jpg?v=202506"  />
                                    <p>NBA勞資糾紛未解，面臨封館危機</p>
                                </div>
                                
                            </li>
                                                                                <li id="201109" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201109.jpg?v=202506"  />
                                    <p>全面導入電子發票</p>
                                </div>
                                                                    <div><p>獲 Inside 三篇報導，非常爽</p></div>
                                                                    <div><p>關閉玩樂透</p></div>
                                
                            </li>
                                                                                <li id="201108" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201108.jpg?v=202506"  />
                                    <p>隨著人越來越多，玩運彩正式有了社群部與工程部，每天為了泡紅茶而對抗</p>
                                </div>
                                                                    <div><p>實施 Happy Hour ，每兩週三下午出去玩</p></div>
                                
                            </li>
                                                                                <li id="201106" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201106.jpg?v=202506"  />
                                    <p>搬到新辦公室，終於有了自己的地方</p>
                                </div>
                                
                            </li>
                                                                                <li id="201105" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201105.jpg?v=202506"  />
                                    <p>推出新版手機網頁</p>
                                </div>
                                                                    <div><p>中部員工旅遊</p></div>
                                                                    <div><p>與聯合晚報合作，評選站上人氣使用者，成為晚報分析師</p></div>
                                
                            </li>
                                                                                <li id="201104" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201104.jpg?v=202506"  />
                                    <p>推出 MLB即時比分</p>
                                </div>
                                
                            </li>
                                                                                <li id="201103" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201103.jpg?v=202506"  />
                                    <p>推出小額付費機制，終於可以用手機買噱幣</p>
                                </div>
                                
                            </li>
                                                                                <li id="201102" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201102.jpg?v=202506"  />
                                    <p>再租一間小辦公室，整體辦公室面積擴大為六坪</p>
                                </div>
                                                                    <div><p>導入 Facebook 登入</p></div>
                                
                            </li>
                                                                                <li id="201101" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201101.jpg?v=202506"  />
                                    <p>推出玩樂透網站</p>
                                </div>
                                
                            </li>
                                                                                <li id="201011" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201011.jpg?v=202506"  />
                                    <p>推出單場殺手</p>
                                </div>
                                
                            </li>
                                                                                <li id="201010" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201010.jpg?v=202506"  />
                                    <p>第二次員工旅遊，在太魯閣遇到梅姬大颱風..</p>
                                </div>
                                
                            </li>
                                                                                <li id="201009" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201009.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>香港合資計畫破局，暫停香港站計畫</p>
                                </div>
                                
                            </li>
                                                                                <li id="201007" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201007.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>主機當機，工友們 3天只睡 10小時，崩潰..</p>
                                </div>
                                
                            </li>
                                                                                <li id="201006" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201006.jpg?v=202506"  />
                                    <p>推出好友圈</p>
                                </div>
                                
                            </li>
                                                                                <li id="201004" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201004.jpg?v=202506"  />
                                    <p>第一次員工旅遊，全員一起騎腳踏車到墾丁</p>
                                </div>
                                
                            </li>
                                                                                <li id="201003" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201003.jpg?v=202506"  />
                                    <p>正式與聯合晚報合作，提供賽事資訊</p>
                                </div>
                                                                    <div><p>每日造訪突破 30,000人次</p></div>
                                                                    <div><p>因操作錯誤，竟然把半年內文章誤刪了</p></div>
                                
                            </li>
                                                                                <li id="201001" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/201001.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>開始販售預測，產生第一筆佛心噱幣訂單，第一天業績 2,595元</p>
                                </div>
                                
                            </li>
                                                                                <li id="200912" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200912.jpg?v=202506"  />
                                    <p>推出莊家殺手</p>
                                </div>
                                
                            </li>
                                                                                <li id="200911" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200911.jpg?v=202506"  />
                                    <p>導入國際盤預測</p>
                                </div>
                                                                    <div><p>每日造訪突破 20,000人次</p></div>
                                
                            </li>
                                                                                <li id="200910" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200910.jpg?v=202506"  />
                                    <p>七家電視媒體報導，第一次被嚇到。</p>
                                </div>
                                                                    <div><p>網址 "playsport.com.tw" 正式改成 "playsport.cc"</p></div>
                                
                            </li>
                                                                                <li id="200909" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200909.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>推出「玩運彩噱報」，提供每日運彩分析</p>
                                </div>
                                
                            </li>
                                                                                <li id="200908" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200908.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>獲Yahoo!奇摩報導，第一次上媒體</p>
                                </div>
                                                                    <div><p>正式成立公司，雇用員工。辦公室從一張小桌子，升級成三坪辦公室</p></div>
                                
                            </li>
                                                                                <li id="200907" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200907.jpg?v=202506"  />
                                    <p>每日造訪突破10,000人次</p>
                                </div>
                                                                    <div><p>入圍資策會WEB2.0創新大募集、Idea show</p></div>
                                
                            </li>
                                                                                <li id="200904" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200904.jpg?v=202506"  />
                                    <p>隱身在殯葬公司，有了第一個辦公桌</p>
                                </div>
                                
                            </li>
                                                                                <li id="200903" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200903.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>每日造訪突破1,000人次</p>
                                </div>
                                
                            </li>
                                                                                <li id="200902" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200902.jpg?v=202506"  />
                                    <p>玩運彩正式開站</p>
                                </div>
                                
                            </li>
                                                                                <li id="200811" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200811.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>發現「瘋運彩」被使用，改名為「玩運彩」</p>
                                </div>
                                
                            </li>
                                                                                <li id="200810" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200810.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>找到外包工程師小毛，建構瘋運彩雛型</p>
                                </div>
                                
                            </li>
                                                                                <li id="200808" >
                                <div class="issues-textandimage">
                                                                        <img src="/images/timeline/200808.jpg?v=202506" style='visibility: hidden; width: 150px; height: 150px;' />
                                    <p>失業的阿達，決定要做運彩網站 - 「瘋運彩」</p>
                                </div>
                                
                            </li>
                                            </ul>
                    <div id="grad_top"></div>
                    <div id="grad_bottom"></div>
                    <a href="#" id="next">+</a>
                    <a href="#" id="prev">-</a>
                </div>
            </div><!--tab2-->

        </div><!--tab_container-->
    </div><!--common-tabs aboutus-tabs-->
</div>

<!--TAB JS START-->
<script type="text/javascript">
    $(function(){
                    var _showTab = 0;
                $('.common-tabs').each(function(){
            var $tab = $(this);
            $('ul.tabs li', $tab).eq(_showTab).addClass('active');
            $('.tab_content', $tab).hide().eq(_showTab).show();
            $('ul.tabs li', $tab).click(function() {
                var $this = $(this),
                    _clickTab = $this.find('a').attr('href');
                $this.addClass('active').siblings('.active').removeClass('active');
                $(_clickTab).stop(false, true).fadeIn().siblings().hide();
                return false;
            }).find('a').focus(function(){
                this.blur();
            });
        });
    });
</script>
<!--TAB JS END-->

<!--TIMELINE START-->
<script src="includes/js/jquery.timelinr-0.9.4.js"></script>
<script type="text/javascript">
$(function(){
    $().timelinr({
        orientation:    'vertical',
        issuesSpeed:    300,
        datesSpeed:     100,
        arrowKeys:      'true',
        startAt:        1
    });
});
</script>
<!--TIMELINE END-->

<!-- google +1 Button -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js">
    {lang: 'zh-TW'}
</script>
                                                                </div>
                </div>
            </div>
                        <div class="footerbox-whole">
                <div class="footerbox">


                    <!-- ==================== #8380 加大手機版footer ==================== -->

                                            <!-- 電腦版 -->
                        <ul class="footerhint">
                            <div class="service_time">09:30~24:00</div><!--新增時間-->
                                                        <li><strong class="service_phone">客服電話</strong><span>07-9700123</span></li><!--新增時間-->
                            <li><a href="/contact.php?back=L2Fib3V0dXMucGhw">聯絡我們</a></li>
                            <li><a href="/qa.php">常見問題</a></li>
                            <li><a href="/utos.php">服務條款</a></li>
                        </ul>
                        <div class="footernav">
                            <ul>
                                <li><a href="/aboutus.php">關於我們</a></li>
                            </ul>
                        </div>
                                            

                    
                    <!-- ==================== #8380 加大手機版footer ==================== -->


                    <p class="copyrights">&copy; 2025 玩運彩 <span>法律顧問：漢英得力法律事務所 陳鎮宏律師</span>
                                                                </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                    <p class="recaptcha">
                        This site is protected by reCAPTCHA and the Google <a class="recaptcha__link" href="https://policies.google.com/privacy">Privacy Policy</a> and <a class="recaptcha__link" href="https://policies.google.com/terms">Terms of Service</a> apply.
                    </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                </div>
                <!-- Trademark -->
                            </div>
                    </div>
                		<script type="text/javascript">
		if ( top.location !== self.location ) {
			top.location=self.location;
		}
        $(function() {
            $('#navi .carditem').on('click', function () {
                // 紀錄使用者有補卷通知時點擊購牌清單的動作
                if ($("#js-coupon-issued").length > 0) {
                    $.post('/user_actions.php?action=setEvent', {name: 'ShoppingListDropdownMenuBTN'});
                }
            });
            $('.js-promotion_event').on('click', function () {
                // 版標特別要加events或ga
                if ($(this).data('events') != '') {
                    PLS.sentEvent($(this).data('events'));
                }
                if ($(this).data('categroy') != '' && $(this).data('lable') != '') {
                    PLS.sentGaEvent($(this).data('categroy'), 'click', $(this).data('lable'));
                }
            });
        })
		</script>
                                                <script>
                    </script>
                    <script>
                ga('send', 'pageview');
            </script>
                    </body>
</html>
