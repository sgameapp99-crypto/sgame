<!DOCTYPE html>
<html lang="zh-Hant">
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&family=Teko:wght@300..700&display=swap" rel="stylesheet">
        <meta name="google" content="notranslate" />
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="format-detection" content="telephone=no">
        <meta name="hostname" content="webServer1">
                                    <meta name="keywords" content="台灣運彩,討論區,賽事討論,運動討論,運動彩券討論,運彩討論,運彩分析,運動分析,運動彩券分析,運動彩券,運動彩,運彩,玩運彩,玩韻彩,完運彩,完韻采,運彩朋友圈,賽事預測,美國職棒,日本職棒,中華職棒,NBA,MLB,足球,韓國職棒,墨西哥棒球,韓國女籃,日本職籃,中國職籃,韓國職籃,俄羅斯冰球,美式足球,網球,KBO,KHL,NHL,NPB,CPBL,NFL,WNBA,即時比分" />
<meta name="description" content="台灣運彩迷必上，全台最知名的運動彩券網站，要買台灣運彩，先看玩運彩" />

<meta property="og:type" content="website" />
<meta property="og:image" content="https://www.playsport.cc/includes/images/playsport_square_big.png" />
<meta property="og:site_name" content="玩運彩" />
<meta property="fb:admins" content="100003206578531" />

<link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                        <title>服務條款 - 玩運彩 台灣運動彩券朋友圈</title>
                <!--CSS start-->
                        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="0">
        <meta HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
        <link rel="stylesheet" href="//fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="/build/css/layout/layout-ac772369fd.cdn.css?v=20210809">
        <link rel="stylesheet" href="/build/css/layout/style_route_all-1f16896256.css?v=20210809" type="text/css" media="screen"/>
        <link rel="stylesheet" href="/build/css/layout/footerbox-28981caad0.web.css?v=20210809" type="text/css" media="screen"/>
        <!-- ==================== #8380 加大手機版footer ==================== -->
                <!-- ==================== #8380 加大手機版footer end ==================== -->

        <link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                <!--[if lt IE 7]><link rel="stylesheet" href="/CSS/style_ltIE7.css" type="text/css" media="screen" />
        <![endif]-->
        <!--[if IE 7]><link rel="stylesheet" href="/CSS/style_IE7.css" type="text/css" media="screen" /><![endif]-->
        <!--[if IE 8]><link rel="stylesheet" href="/CSS/style_IE8.css" type="text/css" media="screen" /><![endif]-->
        <!--CSS end-->
                <script type="text/javascript" src="/cdn/jquery/jquery-1.11.1.min.js?v=20210809"></script>
                            <!-- all css set in controller -->
                        <link href="/CSS/utos.css" rel="stylesheet" type="text/css" />
                                                            <script type="text/javascript" src="/build/js/layout/layout-eeed8409c8.cdn.js?v=20210809"></script>
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-C8806X8QRW"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
                                                                        gtag('config', 'G-C8806X8QRW');
                                                        </script>
                    <script>
                (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                ga('create', 'UA-6819717-3', 'auto');
                ga('require', 'displayfeatures');
            </script>
                <script type="text/javascript">
            var newMobile=false;
        </script>
        <script src="/build/js/layout-e2d4248546.js?v=20210809"></script>
        <script type="text/javascript">
                    </script>
    </head>
    <body id="playsportcc-utos-id" class="playsportcc-index">
                <div id="rootbox-id" class="rootbox">
                        <div class="headerbox">
                <div class="headerboxin">
                    <!-- header menu start -->
                    <div id="smoothmenu1" class="ddsmoothmenu">

    <!-- ================== #8379 移除header所有次選單過場效果 ======================== -->
    <!-- 添加 純css下拉用class="drop-down-menu" -->
    <ul class="drop-down-menu">
                                <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item js-header-menu--guess" href="/guess?from=header"><span></span>玩競猜</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link js-header-menu--guess"   href="/guess?from=header">遊戲區</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/predict/games?allianceid=1&type=p&from=header"><span></span>預測賽事</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/games?allianceid=1&from=header">預測賽事</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/scale?allianceid=1&from=header">觀看預測比例</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/forum?from=header"><span></span>討論區</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/forum?from=header">運彩版</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/buyPredict/medalFire/1?from=header"><span></span>找高手</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/medalFire/1?ck=1&from=header">莊家殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/singleKiller/1?ck=2&from=header">單場殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/winRate?allianceid=1&from=header">勝率榜</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/mainPrediction?allianceid=1&from=header">主推榜</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/livescore/1?from=header"><span></span>即時比分</a>
                                <ul>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/gamesData/battle?allianceid=1&from=header"><span></span>看數據</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/battle?allianceid=1&from=header">對戰資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/teams?allianceid=1&from=header">球隊資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/standings/3?from=header">戰績排名</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/result?allianceid=1">賽事結果查詢</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/member/search"><span></span>玩家搜尋</a>
                            </li>
                        </ul>
    <br style="clear: left" />
</div>

<style>
        #menu-limited img ,#menu-prizeDraw img{ width:70px; margin-top:4px;}
    </style>

                    <!-- header menu end -->
                    <div id="navi" class="default">
                        <div class="fixedpos" id="fixedposid">
                                                            <ul id="functionbarid" class="functionbar">
    <li class="loginitem"><a id="headerLoginButton" class="headerLoginButton cboxElement tween" href="/member/login"><i class="material-icons md-small">&#xE897;</i>登入</a></li>
    <li class="signupitem"><a href="/member/register" class="tween"><i class="material-icons md-small">&#xE7FE;</i>加入會員</a></li>
</ul>
<script type="text/javascript" src="/includes/js/global.js?v=20210809"></script>
<style>
.loginLightbox #cboxContent, .loginLightbox #cboxLoadedContent {
    border: 0;
    background: none;
    color: #000;
}
</style>
<script>
$(function() {
    var notLoginJsonData = {"isMobile":false};
    if (notLoginJsonData.isMobile) {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            location.href = '/member/login';
        });
    } else {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            var redirectUrl = $(this).data('redirecturl');
            $('a.headerLoginButton').colorbox({
                href:"/member/login",
                width: 386,
                height: 634, //登入按鈕x2：542
                className: 'loginLightbox',
                onComplete: function() {
                    $('#login-panel input[name="redirectUrl"]').val(redirectUrl);
                    $('.loginLightbox .ui-dialog-titlebar-close').click(function(event) {
                        $.colorbox.close()
                    });
                    // $(this).colorbox.resize();
                }
            });
        });
    }
})
</script>
                                                     </div>
                    </div>
                    <!-- logo start -->
                    <style type="text/css">.logobox-headerTheme {display: none;}</style>
                                        <div class="logobox">
                        <a href="/forum?redirect_from=headerLogo" target="_top">
                            <img src="/images/logo.png" alt="玩運彩" border="0" width="140" height="57">
                        </a>
                    </div>
                                        <!-- logo end -->

                    <script src="/includes/js/nagging-menu.js?v=20210809"></script>

                    <script type="text/javascript">
                    $(function() {
                        $("body").click(function(event) {
                            if(event.target.id == 'navi'){
                                $.scrollTo(0, 500);
                            }
                        });
                    });
                    </script>
                </div>
            </div>
                        <div class="contentbox">
                                                <div class="winnermarkmask ">
                    <ul class="winnermark ">
                                                <li>
                            <a  id="winnerurl-0" href="https://www.playsport.cc/medal_fire_rank.php?alliance=3" onmouseover="winnercolor('0','set');" onmouseout="winnercolor('0','unset');">
                                <span class="winnerid" id="winnerid-0">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    ★★★第412期莊家殺手出爐★★★                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-1" href="https://www.playsport.cc/single_killer_rank.php?alliance=3" onmouseover="winnercolor('1','set');" onmouseout="winnercolor('1','unset');">
                                <span class="winnerid" id="winnerid-1">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    ☆☆☆第179期單場殺手出爐☆☆☆                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-2" href="https://www.playsport.cc/app_campaign.php?" onmouseover="winnercolor('2','set');" onmouseout="winnercolor('2','unset');">
                                <span class="winnerid" id="winnerid-2">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    秒秒更新！超快即時比分，立刻下載                            </a>
                        </li>
                                            </ul>
                </div>
                                <div class="mainconbox">
                    <div class="mainconboxin mainconboxinwide ">
                                                                    <!--販售預測規範 修改 start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="common-box utos-box">
    <div class="common-tabs utos-tabs">
        <ul class="tabs">
            <li><a href="#tab1">服務條款</a><span></span></li>
            <li><a href="#tab2">隱私權政策</a><span></span></li>
            <li><a href="#tab3">販售預測規範</a><span></span></li>
        </ul>
        <div class="tab_container">
            <div id="tab1" class="tab_content">
                        <div class="common-article-box">
            <p>歡迎您加入「玩運彩 網站平台」會員並使用 玩運彩 網站平台所提供之各項會員服務，玩運彩網站平台會員服務包含玩運彩網站及玩樂透網站所提供之會員服務（以下簡稱「本服務」），「玩運彩 網站平台」是由玩運彩網路有限公司所經營。當您註冊完成或開始使用「本服務」所提供之各項會員服務時，即視為您已經閱讀、瞭解並同意「本服務」條款（以下簡稱「本服務條款」），關於「本服務條款」係規範您與「本服務」提供人之契約。如果您不同意本約定書的內容，或者您所屬的國家或地域排除本約定書內容之全部或一部時，您應立即停止使用「本服務」。</p>
            <p>如您是未滿二十歲之未成年人，則您必須在加入會員前將 「本服務條款」請您的父母或監護人閱讀，並得到其同意，才可以註冊及使用「本服務」。當您使用「本服務」時，即視為您的父母或監護人已經閱讀、瞭解並同意 「本服務條款」。</p>
        </div>

    <div class="common-article-box">
        <h1>您的註冊義務</h1>

            <ul class="common-liststyle">
                <li>請依註冊申請程序所提示之項目，登錄您本人正確、真實及完整之個人資料。當您的個人資料有異動時，請立即更新，以維持您個人資料之正確、真實及完整。如因您登錄不實資料或冒用他人名義以致於侵害他人之權利或違法時，應自負法律責任。</li>
                <li>如您所提供個人資料不實或個人資料有異動但沒有更新以致於與原登錄之資料不符時，「本服務」有權隨時終止您的會員資格及各項會員服務。</li>
                <li>請勿使用他人姓名、別名、違反善良風俗或傷害會員之暱稱，若經認定不適當，本站有權隨時予以凍結或刪除帳號或終止會員資格。</li>
            </ul>

        </div>

        <div class="common-article-box">
        <h1>會員服務</h1>
            <ul class="common-liststyle">
                <li>於您註冊程序完成並由「本服務」完成相關設定後，您即取得「本服務」會員之資格，您可以開始使用「本服務」。</li>

                <li>當您成為「本服務」會員後而得使用之各項會員服務，其所有權仍屬「本服務」及其所約定之人所有，會員僅得依「本服務條款」之約定且限於本人使用，不得出租、出借、分享、移轉或讓與給其他第三人使用。</li>
                <li>「本服務」有權增加、變更或取消會員服務中相關系統或功能之全部或一部之權利且無須個別通知會員；且有關現有或將來之各項服務均受「本服務條款」之規範。</li>
            </ul>
        </div>

        <div class="common-article-box">
            <h1>「本服務」隱私權保護政策</h1>
            <p>您的註冊資料及其他相關資料，均受到「隱私保護政策」保護，請瞭解以保障您的權益。</p>
        </div>

        <div class="common-article-box">
            <h1>會員帳號及密碼之保管</h1>


                <ul class="common-liststyle">
                    <li>您註冊完成後將會取得<u>一組帳號及密碼</u>，您有義務妥善保管您的帳號及密碼之機密與安全，不得洩漏給任何第三人。您必須為此組帳號及密碼之一切行為負責，此組帳號及密碼所做之一切行為即視為您本身之行為。</li>
                    <li>本組帳號及密碼僅限於您個人使用，您不得出租、分享、出借、移轉或讓與給其他第三人使用。</li>
                    <li>如您發現您的帳號及密碼遭盜用或其他不當使用，您必須立即通知「本服務」，以利「本服務」採取相關措施。但不得將「本服務」所採取之措施解釋為「本服務」對您有明示或默示擔保或賠償責任，對於您的帳號及密碼遭人非法使用，「本服務」亦不負任何賠償責任。</li>
                    <li>每次使用完畢後，應確實登出並結束您帳號及密碼的使用，以防止被他人盜用。</li>
                </ul>
            </div>

            <div class="common-article-box">
                <h1>兒童及青少年之保護</h1>
            <p>因網路上之資訊眾多，難免有不適合於兒童及青少年之資訊存在，如暴力、色情或犯罪等資訊，為保護兒童及青少年受到不當資訊的影響，父母或監護人必須盡到以下之義務：</p>

                <ul class="common-liststyle">
                    <li>必須於兒童或青少年使用「本服務」時檢查其交友狀況及隱私權保護政策。</li>
                    <li>對於十二歲以上未滿十八歲之青少年，應避免其接觸含有暴力、色情或鼓勵犯罪等資訊之訊息；對於未滿十二歲之兒童，則應全程陪同其上網，以避免兒童接觸到不當資訊。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>會員之義務</h1>

                <ul class="common-liststyle">
                    <li>會員同意接受「本服務」會員中心寄發的會員電子報。若您不想要接收電子報，請盡速通知我們，將予以取消電子報之發送。</li>

                    <li>除了遵守「本服務條款」之約定外，您同意遵守「本服務」之各項服務營業規章、及網際網路國際使用慣例與禮節之相關規定，並同意<u>不從事以下行為</u>：
                    <ul class="common-liststyle">
                        <li>有抄襲、竊取、更改、破壞本服務、其他會員公開或販售之賽事預測，或他人資訊情事者。</li>
                        <li>有擅自複製本服務、其他會員公開或販售之賽事預測，或他人資訊轉售、分享、轉載情事者。</li>
                        <li>未經對方同意，擅自寄發電子廣告信件至對方信箱者。</li>
                        <li>於討論區或回應區張貼與主題無關之訊息者。</li>
                        <li>蓄意破壞本服務或他人信箱或其通信設備者。</li>
                        <li>散播電腦病毒者。</li>
                        <li>所為言論違背公序良俗者。</li>
                        <li>擷取非經所有者正式開放或授權之資源者。</li>
                        <li>侵害本服務或他人智慧財產權或其他權利或有侵害之虞者。</li>
                        <li>未經同意收集他人電子郵件位址及其他個人資料者。</li>
                        <li>使用任何不雅或有違善良風俗之圖像、文字、聲音、影像作為發表內容者。</li>
                        <li>傳送、張貼或發表或任何虛偽不實或引人錯誤之廣告或其他表示或表徵者。</li>
                        <li>其他有危害通信或違反法令之情事或之虞者。</li>
                        <li>未經本站同意，於本站進行商業置入者。</li>
                    </ul>
                    </li>
                    <li>上述規定不代表「本服務」對會員傳送、張貼或發表之內容做任何形式或實質之審查，會員必須對自己所做之行為負責。如經「本服務」察覺或經他人申訴會員有違反上述各款之情事或之虞時，「本服務」除有權逕行移除或刪除該內容外，並有權終止或暫停該會員之會員資格及各項會員服務(包含凍結會員噱幣、兌換券、分潤）。「本服務」如因此產生損害或損失，並得向該會員請求賠償（包括訴訟及律師費用）。</li>
                    <li>意圖或實際於本站操作兩個以上帳號，本站有權停止或限制部分服務。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>服務暫停或中斷</h1>

                <ul class="common-liststyle">
                    <li>「本服務」於下列情形之一時，得暫停或中斷「本服務」之全部或一部，對於使用者不負擔任何賠償責任：
                    <ul class="common-liststyle">
                        <li>對於「本服務」相關系統設備進行遷移、更換或維護時。</li>
                        <li>因不可歸責於「本服務」所造成服務停止或中斷。</li>
                        <li>因不可抗力所造成服務停止或中斷。</li>
                    </ul>
                    </li>

                    <li>如因「本服務」對於「本服務」相關系統設備進行遷移、更換或維護而必須暫停或中斷全部或一部之服務時，「本服務」於暫停或中斷前將於官方部落格或「本服務」上公告。</li>
                    <li>因使用者違反法令或「本服務條款」或因不可歸責於「本服務」之事由而造成「本服務」之全部或一部暫停或中斷時，暫停或中斷期間之費用仍依正常標準計費。</li>
                    <li>（四）對於「本服務」之暫停或中斷，可能造成您使用上的不便、資料遺失或其他經濟及時間上之損失，您平時應採取適當的防護措施，以保障您的權益。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>網路資源之使用</h1>

                <ul class="common-liststyle">
                    <li>網際網路係開放性網路，並由各網路提供者負責維護，「本服務」無法就使用者擷取資訊資源之正確性、完整性、安全性、可靠性、合法性、不會斷線及出錯負責，亦不保證使用者與「本服務」間資料傳輸速率，倘客戶因傳輸速率或擷取使用網路資料而導致直接或間接之損害或損失時，「本服務」不負任何損害賠償責任。</li>

                    <li>「本服務」網路上可擷取之任何資源，皆屬該資料所有者所擁有，使用者應遵守各該網路資訊所有者之授權或其他法律規定，否則不得使用該等資源，如因此導致任何責任皆由使用者自行負責，概與「本服務」無涉。</li>
                </ul>
            </div>

            <div class="common-article-box">
                <h1>會員服務之措施及限制</h1>

                <ul class="common-liststyle">
                    <li>您同意「本服務」有權就「本服務」訂定相關的措施及限制。</li>

                    <li>如「本服務」將會員傳送之任何訊息及內容刪除或未儲存，「本服務」不負擔任何損害賠償責任，您應自行定期備份資料。</li>

                    <li>「本服務」得因業務考量，隨時變更該措施及限制，對於前述所做之變更，將不對會員個別通知或公告。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>資訊或建議</h1>
            <p>「本服務」所出現的資訊可能因為「本服務」、其他協力廠商及相關電信業者網路系統軟硬體設備之故障或失靈而全部或一部暫時無法使用、或造成資料傳輸錯誤、或遭第三人侵入系統竄改或偽造變造資料等；因此使用者在閱讀或使用所有出現在「本服務」上的資訊時，包括各種資料、建議、分析、評論和報導等，都應該特別謹慎，該等資訊既不代表「本服務」的言論或意見，「本服務」也無法擔保其真實性、完整性及可信度，「本服務」所有資訊和連結，都只是為了提供給使用者自行研究參考，並非對使用者作任何有關專業建議或暗示，亦無法取代或補充專業顧問之個別分析建議，使用者在作成任何具體決定時，應該自行謹慎作成判斷，或者另外洽詢專業顧問。使用者基於「本服務」上的任何資訊所作成的任何決定，都必須自行負擔風險，「本服務」不負任何責任。</p>
        </div>

           <div class="common-article-box">
            <h1>與第三人網站之連結</h1>
            <p>「本服務」與其他網站之連結，僅在提供使用者方便且迅速連結的資訊，您透過交換連結所得的資料由第三人網站所提供，不代表「本服務」與連結網站之業者有任何合作關係。如您因到達該網站而產生之糾紛或損害，請您逕行與該網站之業者聯絡，「本服務」不負任何責任。
            </p>
        </div>


            <div class="common-article-box">
                <h1>廣告</h1>
            <p>「本服務」所傳播或刊載之廣告，關於其內容所展現的文字、圖片、動畫、聲音、影像或以其他方式對商品或服務之說明，都是由廣告主或廣告代理商所提供，對於廣告之內容，「本服務」基於尊重廣告主或廣告代理商權利，不對廣告之內容進行審查。您應該自行判斷該廣告的正確性及可信度，「本服務」不對該廣告做任何擔保。
            </p>
        </div>



            <div class="common-article-box">
                <h1>商品或服務之交易</h1>
            <p>如果您透過「本服務」與網路上其他會員或業者進行商品或服務之買賣或各種交易行為，此時僅該會員或業者與您有契約關係存在，「本服務」並不介入或參與。如有該商品或服務有任何瑕疵或糾紛時，請您逕行與該會員或業者聯絡解決，「本服務」對此不負任何擔保責任。如果商品或服務是「本服務」所提供，則相關權利義務依各會員服務所訂定之相關規定辦理。
            </p>
        </div>

            <div class="common-article-box">
                <h1>內容提供者</h1>
            <p>「本服務」之內容如由與他「本服務」有合作關係之公司、業者或廠商所提供，「本服務」基於尊重他人智慧財產權及其他權益，不對其所提供之內容做任何實質的審查，使用者對於內容之正確性及可靠性，應審慎判斷，「本服務」不對此作任何的擔保。該內容如有不實或錯誤，您應該逕行向該內容提供者反映。
            </p>
        </div>

            <div class="common-article-box">
                <h1>擔保責任之免除</h1>

                <ul class="common-liststyle">
                    <li>「本服務」之各項會員服務，依「本服務」既有之規劃提供，對於特定使用者之特殊需求，「本服務」不擔保「本服務」將符合您的所有需求。</li>
                    <li>「本服務」不擔保各項服務之正確、完整、安全、可靠、合適、時效、穩定、不會斷線及出錯。您同意對於您所傳送之檔案及其他資料做備份。關於因傳送過程而造成通訊錄、檔案及其他資料之遺失，「本服務」不負任何擔保責任。</li>

                    <li>對於您於「本服務」中所下載之檔案及其他資料，您應該自行考量其風險，如因下載而造成您電腦系統的損壞或電腦中資料的遺失，「本服務」不負任何擔保責任。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>會員內容之保留或揭露</h1>

                <ul class="common-liststyle">
                    <li>「本服務」有權對於會員所傳送、張貼或發表之內容（包括但不限於文字、圖片、音樂、影像、軟體、資訊及各種資料等）進行審查，確保其內容不會違反善良風俗或造成侵權行為。然而，會員對於使用由其他會員所提供之內容應自行考量其風險。</li>
                    <li>「本服務」基於下列理由會將會員所傳送、張貼或發表之內容保留或揭露：
                    <ul class="common-liststyle">
                        <li>司法或警察機關偵查犯罪需要時。</li>

                        <li>政府機關依法律程序要求時。</li>
                        <li>因會員之行為違反法令或「本服務條款」之規定時。</li>
                        <li>基於維護公益或保護「本服務」或他人權利。</li>
                    </ul>
                    </li>
                </ul>
            </div>

            <div class="common-article-box">
                <h1>購買規範</h1>

                <ul class="common-liststyle">
                    <li>所有在本服務網站所進行的線上消費，本服務網站保留是否接受訂單之權利。</li>
                    <li>相關商品或服務之品質、保固及售後服務，由提供各該商品或服務的提供者負責，但本服務網站將會全力協助使用者解決關於因為線上消費所產生之疑問或爭議。</li>
                    <li>使用者資料（如地址、電話）如有變更時，應立即上線修正其所留存之資料，或通知本服務網站修正，且不得以資料不符為理由，否認其訂購行為或拒絕付款。</li>
                    <li>所有在本服務網站所進行的線上消費，使用者應同意以本服務網站之交易紀錄為準，如有糾紛，並以該交易紀錄為認定標準。使用者如果發現交易紀錄不正確，應立即通知本服務網站。</li>
                    <li>當使用者訂單成立之後，為確保為本人授權之交易，本服務網站得保留向持卡人索取信用卡背面簽名傳真與訂單確認傳真之權利。</li>
                    <li>您瞭解所有玩運彩噱幣，一經購買後，即表示您已經確認本服務所處理之結果，本公司無法進行回復、退費或轉讓等動作，而且玩運彩噱幣之權利義務適用該本公司所有相關規定。同時，若是因為您的保管疏忽，而導致帳號、密碼遭他人非法使用時，本公司將不負責處理。若您於本服務中與他人為任何交易或互易行為，因此而產生的糾紛，本公司恕不負責，本公司亦無法進行回復或退費等動作，但本服務可提供相關交易紀錄以供查詢。若本公司無法收到您經由線上刷卡或其他不是使用現金方式購買玩運彩噱幣或其他商品的費用時，您同意本公司有權停止與該項交易相關之帳號。 </li>
                    <li>本服務之玩運彩噱幣，交易僅提供會員於本服務平台上使用，任何會員不得移作其他用途或私自販售，例如私做實體點數卡，否則將視為侵權行為，本公司得要求所有相關之損失及費用，其包括但不限於違約金、訴訟費、律師費、及和解金等相關費用</li>
                    <li>所有在本服務網站所進行的線上消費，如有消費爭議時，使用者同意將個人相關資料提供給第三方金流廠商，進行相關消費了解與查詢。</li>
                    <li>本公司所開立之發票依<a href="https://law-out.mof.gov.tw/LawContent.aspx?id=GL007236">統一發票使用辦法規定</a>，只有書寫錯誤得換開；個人戶發票無法換開為公司戶發票；公司戶發票無法換開為個人戶發票。發票一經開立，對於買方名稱及統一編號不得任意更改或應買方要求改開其他營利事業及統一編號。</li>
                </ul>
            </div>

            <div class="common-article-box">
                <h1>補償</h1>

            <p>
                您同意補償本公司及一切相關人員，因您違反相關法令或本服務條款所致生之一切損害及責任，包括但不限於訴訟及律師費用。
            </p>
            </div>


            <div class="common-article-box">
                <h1>風險</h1>
            <p>
                請本諸謹慎、合於常理判斷、交易安全性 ( 包括但不限於對方交易者行為能力、身份真實性、與法定年齡以下之人交易、國際貿易等風險 ) 等的考量使用本服務。
                </p>
            </div>

            <div class="common-article-box">
                <h1>智慧財產權</h1>
            <p>「本服務」上所使用或提供之軟體、程式及內容（包括但不限於文字、說明、圖畫、圖片、圖形、檔案、頁面設計、網站規劃與安排等）之專利權、著作權、商標權、營業秘密、專門技術及其他智慧財產權均屬「本服務」或其他權利人所有，非經權利人事先書面授權同意，會員不得擅自重製、公開傳播、公開播送、公開上映、改作、編輯、出租、散佈、進行還原工程、解編、反向組譯、或其他方式之使用，如有違反，除應自行負法律責任外，如因而對「本服務」造成損害或損失，「本服務」得向該會員請求損害賠償。
            </p>
        </div>

            <div class="common-article-box">
                <h1>特別規定</h1>
            <p>「本服務條款」係就「本服務」之各項服務所作之一般規定，如各該會員服務有特別規定時，則先依各該特別規定。
            </p>
        </div>

            <div class="common-article-box">
                <h1>服務條款之增訂及修改</h1>

            <p>「本服務條款」如有增訂或修改，您同意自該修訂條款於「本服務」公告之時起受其拘束，「本服務」將不對會員個別通知。如您於公告後繼續使用「本服務」，則視為您已經同意該修訂條款。
            </p>
        </div>


            <div class="common-article-box">
                <h1>玩運彩賽事預測及玩樂透樂透預測</h1>

                <ul class="common-liststyle">
                    <li>會員同意授權「本服務」，得為提供服務及贈獎之目的，提供必需之會員資料給合作夥伴(第三者)做約定範圍內之妥善使用，倘若會員不同意將其資料列 於合作夥伴(第三者)產品或服務名單內，可以通知「本服務」，於名單中刪除其資料，同時放棄其「本服務」購物以外之優惠或獲獎權利。</li>
                    <li>對於會員所登錄或留存之個人資料，會員同意「本服務」得於合理之範圍內蒐集、處理、保存、傳遞及使用該等資料，以提供使用者其他資訊或服務、或作成會員統計資料、或進行關於網路行為之調查或研究，或為任何之合法使用。</li>
                    <li>若會員無合法權利得授權他人使用、修改、重製、公開播送、改作、散佈、發行、公開發表某資料，並將前述權利轉授權第三人，請勿擅自將該資料上載、傳送、輸入或提供至「本服務」。任何資料一經您上載、傳送、輸入或提供至「本服務」時，視為您已允許「本服務」無條件使用、修改、重 製、公開播送、改作、散佈、發行、公開發表該等資料，並得將前述權利轉授權他人，您對此絕無異議。您並應保證「本服務」使用、修改、重製、公開 播送、改作、散佈、發行、公開發表、轉授權該等資料，不致侵害任何第三人之智慧財產權，否則應對「本服務」負損害賠償責任（包括但不限於訴訟費 用及律師費用等）。</li>
                </ul>
            </div>


            <div class="common-article-box">
                <h1>準據法及管轄法院</h1>

                <ul class="common-liststyle">
                    <li>關於「本服務條款」之解釋或適用，以中華民國之法律為準據法。</li>
                    <li>會員因使用「本服務」而與「本服務」所生之爭議，同意本誠信原則解決之，如有訴訟之必要時，同意以台灣台北地方法院為第一審管轄法院。</li>
                </ul>
            </div>            </div>
            <div id="tab2" class="tab_content">
                <div class="common-article-box">
    <h1>隱私權政策</h1>
    <p>
        本隱私權政策適用於玩運彩網站平台所提供之任何服務，玩運彩網站平台(以下稱為本網站)包含玩運彩網站及Android/iOS即時比分APP、Android/iOS討論區APP之服務，
        為了使玩運彩網站平台的隱私權政策適用於本網站上之所有商品、服務、活動，
        凡任何接觸該網站的參訪者、使用者、創作者、設計師或合作廠商皆受到本隱私權政策的保護及規範。
    </p>
</div>
<div class="common-article-box">
    <h1>蒐集個人資料</h1>
    <p>
        瀏覽網頁時，本網站並不會要求您登入帳號，也不會要求您提供個人資料。除非在特定告知情況下，本網站不會取得您的個人資料。
        然而，若您要從事某些活動(如賽事預測、發表文章或評論等行為)時，則需要註冊並登入帳號。
    </p>
    <p>
        當您註冊時，本網站會請您提供您的相關個人資料。註冊帳號後，本網站會蒐集您的個人資料，
        當您使用本網站的某些服務時，本網站會根據您提供的資料完成服務。
    </p>
    <p>
        當您使用Android/iOS討論區APP時，本網站會請您提供您的相簿、相機資訊，提供資訊後，本網站會蒐及您的相關資料，
        當您使用APP的某些服務時，本網站會根據您提供的資料完成服務。
    </p>
    <p>
        無論在登入或未登入情況下，本網站會自動取得並記錄其他非個人性資料，如您的IP位址、網站內的瀏覽活動等。
        這些資料僅使用非個人性資料進行流量分析或行為調查，以提升本網站的服務品質，或提供匿名資訊給內、外部客戶。
    </p>
</div>
<div class="common-article-box">
    <h1>使用個人資料</h1>
    <p>本網站不會出售、出租或提供您的個人資料給任何非合作的個人或廠商，除非取得您的同意，或是下列狀況：</p>
    <ul class="common-liststyle">
        <li>我們可能提供您的資料給予以信任的相關合作廠商。這些廠商可能會使用您的資料，以提升本網站提供給您的服務。然而，這些廠商沒有權利單獨使用您的個人資料。</li>
        <li>我們可能提供非個人資料的分析與統計給予第三人或公司，以提升本網站的設計、功能、服務等。</li>
        <li>依法令或政府機關之要求，本網站僅得提供使用者之識別資料予第三人。</li>
        <li>若您主張網友之侵權行為，而該網友對您主張的侵權行為有異議時，本網站得將您的姓名、電子郵件或電話提供予該網友俾該網友得直接與您溝通解決爭議。</li>
    </ul>
</div>
<div class="common-article-box">
    <h1>刪除帳號和個人資料</h1>
    <p>如有刪除帳號和個人資料的需求，請<a href="/contact.php">聯絡我們</a>，並提供您的姓名，使用者帳號、電子信箱、聯絡電話，核對身分完成後，將由站方人員協助您相關刪除事項</p>
</div>
<div class="common-article-box">
    <h1>Cookies</h1>
    <p>
        為提供更便利的服務，在本網站中可能會使用cookie。所謂cookie，係指一小則可讀取的資訊，其係由網站將其儲存於您個人電腦網站瀏覽器內。
        只有 原設置cookie的網站能讀取其內容。使用cookies大多基於輔助作用，例如儲存您偏好的特定種類資料，或儲存相關密碼以方便您上網至本網站時不必 每次再輸入密碼。
        大部分cookies的有效性只持續一定期間或只限單次造訪。Cookie並不含任何資料足使他人透過電話、電子郵件與您聯絡。
        您可在您的網站瀏覽器上設定功能以獲知何時cookies被設置或避免cookies的設置。
    </p>
</div>
<div class="common-article-box">
    <h1>資訊安全</h1>
    <p>本網站將盡最大的努力及技術保障您的個人資訊安全。然而，我們無法完全確保您在本網站的資訊完全安全，您將承擔其中的風險。</p>
</div>
<div class="common-article-box">
    <h1>隱私權政策的修改</h1>
    <p>本網站有權在任何時間、地點或未通知的情況下修改、刪除、新增隱私權政策的權利。當涉及重大改變時，我們會盡最大努力通知您，以確保您使用本網站的權利。</p>
</div>
<div class="common-article-box">
    <h1>修改日期</h1>
    <p>隱私權政策最新修改日期為2017年9月25日。</p>
</div>
<div class="common-article-box">
    <h1>聯絡我們</h1>
    <p>如果您對此隱私權政策有任何疑問或建議，請您聯絡我們。</p>
</div>
            </div>
            <div id="tab3" class="tab_content">
                <div class="common-preface sellrule-preface">
    <h1>
        販售預測相關問題請看<a href="qa.php?tb=3">常見問題</a>，
        亦可<a href="contact.php">聯絡我們</a>及撥打07-9700123
    </h1>
    <a href="qa.php" target="_blank" class="cbt-q">
        <span></span><strong>常見問題</strong>
    </a>
    <a href="contact.php" target="_blank" class="cbt-c">
        <span></span><strong>聯絡我們</strong>
    </a>
    <a href="#" class="cbt-t"><span></span><strong>07-9700123</strong></a>
</div>
<div class="common-article-box">
    <h1>一般規定</h1>
    <ul class="common-liststyle">
        <li>同意消費者使用玩運彩兌換券( 而非噱幣 )觀看已販售預測內容，並不計入分潤所得。</li>
        <li>同意若玩運彩沒有收到消費者購買噱幣費用（小額付款、信用卡等），則退回從該消費者獲得的分潤。</li>
        <li>凡被玩運彩討論區永久禁文者，將無條件取消<u>販售資格</u>及<u>殺手評選資格</u>。</li>
        <li>不得有任一下列違規行為，若有違規行為同意玩運彩站方用販售預測違規處理辦法處理：
            <ul class="common-liststyle">
                <li>嚴重侵犯他人智慧財產權與專利權，抄襲其他會員公開或販售之賽事預測、詐欺、資料造假、蓄意破壞玩運彩規範以及玩運彩會員權益。</li>
                <li>於其他網站販售玩運彩的預測或是以玩運彩的名義販售預測。</li>
                <li>意圖於本站操作兩個以上帳號販售預測、操作兩個以上帳號點選預測或與他人討論後點選預測意圖成為殺手等行為，視同處理。</li>
                <li>不當使用玩運彩帳號而影響玩運彩商譽、風評、其他會員權益。</li>
                <li>未經允許，自行使用玩運彩相關服務Logo於自身網站或未經允許使用玩運彩官方名義。</li>
                <li>販售後又自行對外分享、或公布玩運彩任何需要付費的內容(包含本身販售預測內容)。</li>
                <li>在玩運彩討論區公布與實際預測內容不符合的資訊。</li>
                <li>
                    會員於討論區、說明文及殺手小叮嚀張貼故意誇大、虛偽不實、引人錯誤之資訊、張貼對外連結或是暗示性宣傳同質性外站
                    、張貼辱罵或挑釁等文字、張貼與賽事預測矛盾的資訊或是意圖私下通訊、或於說明文及殺手小叮嚀張貼非販售聯盟的資訊。
                </li>
                <li>將帳號出租、分享、出借、轉移、讓與、或販售給其他第三人使用</li>
            </ul>
        </li>
    </ul>
    <h1>權利歸屬</h1>
    <ul class="common-liststyle">當您輸入賽事預測資訊，包括但不限於說明文及殺手小叮嚀，並經由玩運彩站方系統成為販售預測內容時，即視為該等預測資訊之一切權益，包括但不限於著作權或營業祕密，皆屬於玩運彩站方所有；未經玩運彩站方書面同意，您不得再自行對外分享或販售。</ul>
</div>
<div class="common-article-box">
    <h1>違規處理辦法</h1>
    <ul class="common-liststyle">
        <li>為了維護玩運彩公平秩序以及消費者權益，訂有違規處理辦法，請勿以身試法。</li>
        <li><strong>若莊家殺手(或單場殺手)有任一玩運彩站方認定違反販售預測規範之行為，將被玩運彩站方終止其販售資格、取消殺手評選資格，且分潤所得全數凍結歸零，不得申請提領。</strong></li>
    </ul>
</div>
            </div>
        </div>
    </div>
</div>

<!--販售預測規範 修改 end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<!--TAB JS START-->
<script type="text/javascript">
    $(function(){
                    var _showTab = 0;
                $('.common-tabs').each(function(){
            var $tab = $(this);
            $('ul.tabs li', $tab).eq(_showTab).addClass('active');
            $('.tab_content', $tab).hide().eq(_showTab).show();
            $('ul.tabs li', $tab).click(function() {
                var $this = $(this),
                    _clickTab = $this.find('a').attr('href');
                $this.addClass('active').siblings('.active').removeClass('active');
                $(_clickTab).stop(false, true).fadeIn().siblings().hide();
                return false;
            }).find('a').focus(function(){
                this.blur();
            });
        });
    });
</script>
<!--TAB JS END-->                                                                </div>
                </div>
            </div>
                        <div class="footerbox-whole">
                <div class="footerbox">


                    <!-- ==================== #8380 加大手機版footer ==================== -->

                                            <!-- 電腦版 -->
                        <ul class="footerhint">
                            <div class="service_time">09:30~24:00</div><!--新增時間-->
                                                        <li><strong class="service_phone">客服電話</strong><span>07-9700123</span></li><!--新增時間-->
                            <li><a href="/contact.php?back=L3V0b3MucGhw">聯絡我們</a></li>
                            <li><a href="/qa.php">常見問題</a></li>
                            <li><a href="/utos.php">服務條款</a></li>
                        </ul>
                        <div class="footernav">
                            <ul>
                                <li><a href="/aboutus.php">關於我們</a></li>
                            </ul>
                        </div>
                                            

                    
                    <!-- ==================== #8380 加大手機版footer ==================== -->


                    <p class="copyrights">&copy; 2025 玩運彩 <span>法律顧問：漢英得力法律事務所 陳鎮宏律師</span>
                                                                </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                    <p class="recaptcha">
                        This site is protected by reCAPTCHA and the Google <a class="recaptcha__link" href="https://policies.google.com/privacy">Privacy Policy</a> and <a class="recaptcha__link" href="https://policies.google.com/terms">Terms of Service</a> apply.
                    </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                </div>
                <!-- Trademark -->
                            </div>
                    </div>
                		<script type="text/javascript">
		if ( top.location !== self.location ) {
			top.location=self.location;
		}
        $(function() {
            $('#navi .carditem').on('click', function () {
                // 紀錄使用者有補卷通知時點擊購牌清單的動作
                if ($("#js-coupon-issued").length > 0) {
                    $.post('/user_actions.php?action=setEvent', {name: 'ShoppingListDropdownMenuBTN'});
                }
            });
            $('.js-promotion_event').on('click', function () {
                // 版標特別要加events或ga
                if ($(this).data('events') != '') {
                    PLS.sentEvent($(this).data('events'));
                }
                if ($(this).data('categroy') != '' && $(this).data('lable') != '') {
                    PLS.sentGaEvent($(this).data('categroy'), 'click', $(this).data('lable'));
                }
            });
        })
		</script>
                                                <script>
                    </script>
                    <script>
                ga('send', 'pageview');
            </script>
                    </body>
</html>
