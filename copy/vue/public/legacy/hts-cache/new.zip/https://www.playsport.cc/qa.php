<!DOCTYPE html>
<html lang="zh-Hant">
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&family=Teko:wght@300..700&display=swap" rel="stylesheet">
        <meta name="google" content="notranslate" />
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="format-detection" content="telephone=no">
        <meta name="hostname" content="webServer3PHP8">
                                    <meta name="keywords" content="台灣運彩,討論區,賽事討論,運動討論,運動彩券討論,運彩討論,運彩分析,運動分析,運動彩券分析,運動彩券,運動彩,運彩,玩運彩,玩韻彩,完運彩,完韻采,運彩朋友圈,賽事預測,美國職棒,日本職棒,中華職棒,NBA,MLB,足球,韓國職棒,墨西哥棒球,韓國女籃,日本職籃,中國職籃,韓國職籃,俄羅斯冰球,美式足球,網球,KBO,KHL,NHL,NPB,CPBL,NFL,WNBA,即時比分" />
<meta name="description" content="台灣運彩迷必上，全台最知名的運動彩券網站，要買台灣運彩，先看玩運彩" />

<meta property="og:type" content="website" />
<meta property="og:image" content="https://www.playsport.cc/includes/images/playsport_square_big.png" />
<meta property="og:site_name" content="玩運彩" />
<meta property="fb:admins" content="100003206578531" />

<link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                        <title>常見問題 - 玩運彩 台灣運動彩券朋友圈</title>
                <!--CSS start-->
                        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="0">
        <meta HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
        <link rel="stylesheet" href="//fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="/build/css/layout/layout-ac772369fd.cdn.css?v=20210809">
        <link rel="stylesheet" href="/build/css/layout/style_route_all-1f16896256.css?v=20210809" type="text/css" media="screen"/>
        <link rel="stylesheet" href="/build/css/layout/footerbox-28981caad0.web.css?v=20210809" type="text/css" media="screen"/>
        <!-- ==================== #8380 加大手機版footer ==================== -->
                <!-- ==================== #8380 加大手機版footer end ==================== -->

        <link rel="shortcut icon" href="https://www.playsport.cc/includes/images/star.ico"  type="image/x-icon">
                <!--[if lt IE 7]><link rel="stylesheet" href="/CSS/style_ltIE7.css" type="text/css" media="screen" />
        <![endif]-->
        <!--[if IE 7]><link rel="stylesheet" href="/CSS/style_IE7.css" type="text/css" media="screen" /><![endif]-->
        <!--[if IE 8]><link rel="stylesheet" href="/CSS/style_IE8.css" type="text/css" media="screen" /><![endif]-->
        <!--CSS end-->
                <script type="text/javascript" src="/cdn/jquery/jquery-1.11.1.min.js?v=20210809"></script>
                            <!-- all css set in controller -->
                        <link href="/build/css/qa/qa-2204f297c9.css?v=20210809" rel="stylesheet" type="text/css" />
                                                            <script type="text/javascript" src="/build/js/layout/layout-eeed8409c8.cdn.js?v=20210809"></script>
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-C8806X8QRW"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
                                                                        gtag('config', 'G-C8806X8QRW', {
                            'content_group': '常見問題'
                        });
                                                        </script>
                    <script>
                (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                ga('create', 'UA-6819717-3', 'auto');
                ga('require', 'displayfeatures');
            </script>
                <script type="text/javascript">
            var newMobile=false;
        </script>
        <script src="/build/js/layout-e2d4248546.js?v=20210809"></script>
        <script type="text/javascript">
                    </script>
    </head>
    <body id="playsportcc-qa-id" class="playsportcc-index">
                <div id="rootbox-id" class="rootbox">
                        <div class="headerbox">
                <div class="headerboxin">
                    <!-- header menu start -->
                    <div id="smoothmenu1" class="ddsmoothmenu">

    <!-- ================== #8379 移除header所有次選單過場效果 ======================== -->
    <!-- 添加 純css下拉用class="drop-down-menu" -->
    <ul class="drop-down-menu">
                                <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item js-header-menu--guess" href="/guess?from=header"><span></span>玩競猜</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link js-header-menu--guess"   href="/guess?from=header">遊戲區</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/predict/games?allianceid=1&type=p&from=header"><span></span>預測賽事</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/games?allianceid=1&from=header">預測賽事</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/predict/scale?allianceid=1&from=header">觀看預測比例</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/forum?from=header"><span></span>討論區</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/forum?from=header">運彩版</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/buyPredict/medalFire/1?from=header"><span></span>找高手</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/medalFire/1?ck=1&from=header">莊家殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/buyPredict/singleKiller/1?ck=2&from=header">單場殺手</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/winRate?allianceid=1&from=header">勝率榜</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/billboard/mainPrediction?allianceid=1&from=header">主推榜</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/livescore/1?from=header"><span></span>即時比分</a>
                                <ul>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/gamesData/battle?allianceid=1&from=header"><span></span>看數據</a>
                                <ul>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/battle?allianceid=1&from=header">對戰資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/teams?allianceid=1&from=header">球隊資訊</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/standings/3?from=header">戰績排名</a>
                    </li>
                                        <li>
                                                <a class="ddsmoothmenu-link "   href="/gamesData/result?allianceid=1">賽事結果查詢</a>
                    </li>
                                    </ul>
                            </li>
                                            <li class="ddsmoothmenu-outer">
                                                
                
                <a class="ddsmoothmenu-item " href="/member/search"><span></span>玩家搜尋</a>
                            </li>
                        </ul>
    <br style="clear: left" />
</div>

<style>
        #menu-limited img ,#menu-prizeDraw img{ width:70px; margin-top:4px;}
    </style>

                    <!-- header menu end -->
                    <div id="navi" class="default">
                        <div class="fixedpos" id="fixedposid">
                                                            <ul id="functionbarid" class="functionbar">
    <li class="loginitem"><a id="headerLoginButton" class="headerLoginButton cboxElement tween" href="/member/login"><i class="material-icons md-small">&#xE897;</i>登入</a></li>
    <li class="signupitem"><a href="/member/register" class="tween"><i class="material-icons md-small">&#xE7FE;</i>加入會員</a></li>
</ul>
<script type="text/javascript" src="/includes/js/global.js?v=20210809"></script>
<style>
.loginLightbox #cboxContent, .loginLightbox #cboxLoadedContent {
    border: 0;
    background: none;
    color: #000;
}
</style>
<script>
$(function() {
    var notLoginJsonData = {"isMobile":false};
    if (notLoginJsonData.isMobile) {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            location.href = '/member/login';
        });
    } else {
        $('a.headerLoginButton').click(function(event) {
            event.preventDefault();
            var redirectUrl = $(this).data('redirecturl');
            $('a.headerLoginButton').colorbox({
                href:"/member/login",
                width: 386,
                height: 634, //登入按鈕x2：542
                className: 'loginLightbox',
                onComplete: function() {
                    $('#login-panel input[name="redirectUrl"]').val(redirectUrl);
                    $('.loginLightbox .ui-dialog-titlebar-close').click(function(event) {
                        $.colorbox.close()
                    });
                    // $(this).colorbox.resize();
                }
            });
        });
    }
})
</script>
                                                     </div>
                    </div>
                    <!-- logo start -->
                    <style type="text/css">.logobox-headerTheme {display: none;}</style>
                                        <div class="logobox">
                        <a href="/forum?redirect_from=headerLogo" target="_top">
                            <img src="/images/logo.png" alt="玩運彩" border="0" width="140" height="57">
                        </a>
                    </div>
                                        <!-- logo end -->

                    <script src="/includes/js/nagging-menu.js?v=20210809"></script>

                    <script type="text/javascript">
                    $(function() {
                        $("body").click(function(event) {
                            if(event.target.id == 'navi'){
                                $.scrollTo(0, 500);
                            }
                        });
                    });
                    </script>
                </div>
            </div>
                        <div class="contentbox">
                                                <div class="winnermarkmask ">
                    <ul class="winnermark ">
                                                <li>
                            <a  id="winnerurl-0" href="https://www.playsport.cc/medal_fire_rank.php?alliance=3" onmouseover="winnercolor('0','set');" onmouseout="winnercolor('0','unset');">
                                <span class="winnerid" id="winnerid-0">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    ★★★第412期莊家殺手出爐★★★                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-1" href="https://www.playsport.cc/app_campaign.php?" onmouseover="winnercolor('1','set');" onmouseout="winnercolor('1','unset');">
                                <span class="winnerid" id="winnerid-1">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    秒秒更新！超快即時比分，立刻下載                            </a>
                        </li>
                                                <li>
                            <a  id="winnerurl-2" href="https://www.playsport.cc/single_killer_rank.php?alliance=3" onmouseover="winnercolor('2','set');" onmouseout="winnercolor('2','unset');">
                                <span class="winnerid" id="winnerid-2">
                                                                    </span>
                                <span class="gametype">
                                                                    </span>
                                    ☆☆☆第179期單場殺手出爐☆☆☆                            </a>
                        </li>
                                            </ul>
                </div>
                                <div class="mainconbox">
                    <div class="mainconboxin mainconboxinwide ">
                                                                    <!--常見問題 修改 start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="common-box qa-box">
    <div class="common-tabs qa-tabs">
        <ul class="tabs">
            <li><a href="#tab1">一般問題</a><span></span></li>
            <li><a href="#tab2">殺手評選</a><span></span></li>
            <li><a href="#tab3">販售預測</a><span></span></li>
            <li><a href="#tab4">購買預測</a><span></span></li>
            <li><a href="#tab5">購買噱幣</a><span></span></li>

        </ul>

        <div class="tab_container">
            <div id="tab1" class="tab_content">
                <div class="common-article-box">
    <ul class="qa-list">
        <li>
            <h2>如何修改帳號資料？</h2>
        </li>
        <li>
            <h3>如何修改暱稱：</h3>
            <p>由於資料庫設計關係，暱稱是無法更改的，還請見諒。</p>
            <br>
            <h3>如何修改密碼、大頭照：</h3>
            <p>頁面最上方會顯示您的暱稱，點選暱稱後，進入下方選單中的「設定」，在設定頁面中，即可修改您的密碼、大頭照。</p>
            <br>
            <h3>如何修改/移除帳號：</h3>
            <p>帳號無法更改及移除，若帳號不需使用，請您不再登入即可。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li>
            <h2>如何在討論區上發回文？</h2>
        </li>
        <li>
            <p>在討論區發文需先完成手機號碼認證，於討論區頁面，點選發表文章後，依照畫面指示進行手機認證，完成後即可發回文。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li>
            <h2>為什麼收不到討論區手機認證碼？</h2>
        </li>
        <li>
            <p>有部分的手機號碼可能無法收到認證碼簡訊，或是系統發生錯誤，若您無法收到認證碼簡訊，請使用網頁下方「<a href="contact.php">聯絡我們</a>」告知，或撥打客服電話07-9700123，我們會盡速為您處理。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li>
            <h2>手機號碼認證過了，怎麼辦？</h2>
        </li>
        <li>
            <p>手機號碼一但認證過，將無法更改或移除，若要認證新帳號，只能使用未認證過的手機號碼。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li>
            <h2>為什麼我被刪文？</h2>
        </li>
        <li>
            <p>若文章被刪除，代表工友判斷您的文章有違反版規之虞，詳細的刪文原因，可至您的「個人頁」→「討論」→上方選單「發文」，將滑鼠移至文章列表的最右邊欄位，即會顯示刪除原因。</p>
        </li>
    </ul>
</div>

<a name="level"></a>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>等級如何計算？</h2></li>
        <li>
            <h3>等級列表</h3>
            <div class="qalevel-table-box">
                <table class="qalevel-table">
                    <tr>
                        <th class="qalevel-th-lv">等級</th>
                        <th class="qalevel-th-profit">周獲利標準</th>
                        <th class="qalevel-th-win">周勝率標準</th>
                    </tr>
                                                                                        <tr>
                            <td>30</td>
                            <td>9</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>29</td>
                            <td>9</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>28</td>
                            <td>8</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>27</td>
                            <td>8</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>26</td>
                            <td>7</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>25</td>
                            <td>7</td>
                            <td>85%</td>
                        </tr>
                                                                    <tr>
                            <td>24</td>
                            <td>6</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>23</td>
                            <td>6</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>22</td>
                            <td>6</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>21</td>
                            <td>5</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>20</td>
                            <td>5</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>19</td>
                            <td>5</td>
                            <td>80%</td>
                        </tr>
                                                                    <tr>
                            <td>18</td>
                            <td>4</td>
                            <td>75%</td>
                        </tr>
                                                                    <tr>
                            <td>17</td>
                            <td>4</td>
                            <td>75%</td>
                        </tr>
                                                                    <tr>
                            <td>16</td>
                            <td>4</td>
                            <td>75%</td>
                        </tr>
                                                            </table>
            </div>
            <div class="qalevel-table-box">
                <table class="qalevel-table">
                    <tr>
                        <th class="qalevel-th-lv">等級</th>
                        <th class="qalevel-th-profit">周獲利標準</th>
                        <th class="qalevel-th-win">周勝率標準</th>
                    </tr>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                <tr>
                            <td>15</td>
                            <td>3</td>
                            <td>70%</td>
                        </tr>
                                                                    <tr>
                            <td>14</td>
                            <td>3</td>
                            <td>70%</td>
                        </tr>
                                                                    <tr>
                            <td>13</td>
                            <td>3</td>
                            <td>70%</td>
                        </tr>
                                                                    <tr>
                            <td>12</td>
                            <td>2</td>
                            <td>65%</td>
                        </tr>
                                                                    <tr>
                            <td>11</td>
                            <td>2</td>
                            <td>65%</td>
                        </tr>
                                                                    <tr>
                            <td>10</td>
                            <td>2</td>
                            <td>65%</td>
                        </tr>
                                                                    <tr>
                            <td>9</td>
                            <td>1</td>
                            <td>60%</td>
                        </tr>
                                                                    <tr>
                            <td>8</td>
                            <td>1</td>
                            <td>60%</td>
                        </tr>
                                                                    <tr>
                            <td>7</td>
                            <td>1</td>
                            <td>60%</td>
                        </tr>
                                                                    <tr>
                            <td>6</td>
                            <td>無</td>
                            <td>55%</td>
                        </tr>
                                                                    <tr>
                            <td>5</td>
                            <td>無</td>
                            <td>55%</td>
                        </tr>
                                                                    <tr>
                            <td>4</td>
                            <td>無</td>
                            <td>55%</td>
                        </tr>
                                                                    <tr>
                            <td>3</td>
                            <td>無</td>
                            <td>50%</td>
                        </tr>
                                                                    <tr>
                            <td>2</td>
                            <td>無</td>
                            <td>50%</td>
                        </tr>
                                                                    <tr>
                            <td>1</td>
                            <td>無</td>
                            <td>50%</td>
                        </tr>
                                    </table>
            </div>
            <ol class="common-liststyle">
                <h3>升級條件：</h3>
                <li>
                    <p>各聯盟當週升級注數</p>
                    <ul>10注以上: MLB、日本職棒、韓國職棒、NBA、歐洲職籃、WNBA、NHL冰球、俄冰、足球、賽馬</ul>
                    <ul>8注以上: 中國職籃、日本職籃、韓國職籃、中華職棒 </ul>
                    <ul>6注以上: 澳棒、澳籃、美式足球</ul>
                </li>
                <li><p>周勝率、周獲利需達到列表中的標準。</p></li>
                <li><p>每週一下午計算一次等級(每週至多升一級，不會降級)。</p></li>
                <li><p>每個聯盟的等級是獨立計算的。</p></li>
                <li><p>計算等級時依照國際盤和運彩盤相加起來的成績。</p></li>
                <li><p>勝率計算取四捨五入到小數點第二位。</p></li>
            </ol>
        </li>
    </ul>
</div>
<a id="rankin"></a>
<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>周、月、賽季勝率排行榜的計算方式？</h2></li>
        <li>
            <h3>周勝率排行榜：</h3>
            <p>周勝率排行榜計算每週日 0:00至週六23:59的預測。</p>
            <br>
            <h3>月勝率排行榜：</h3>
            <p>月勝率排行榜計算每月第一天 0:00至每月最後一天23:59的預測。</p>
            <br>
            <h3>賽季勝率排行榜：</h3>
            <p>賽季勝率排行榜計算每個賽季第一天 0:00至賽季最後一天23:59的預測。</p>
            <br><br>
            <ol class="common-liststyle">
                <h3>備註：</h3>
                <li><p>以上均依<strong>「開賽時間」</strong>為準。</p></li>
                <li><p>系統每天下午 2:00~4:00 計算排行榜資料。</p></li>
                <li><p>有關進勝率排行榜最低注數，請看下一題。</p></li>
                <li><p>季後賽場次較少，本站將視狀況調整最低限制注數。</p></li>
            </ol>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>進勝率排行榜的最低注數？</h2></li>
        <li>
            <h3>週、月、賽季勝率排行榜</h3>
            <table class="qa-common-table">
                <tbody>
                    <tr>
                        <th class="qa-common-table-th01">聯盟</th>
                        <th class="qa-common-table-th02">每日最低注數</th>
                    </tr>
                    <tr>
                        <td>MLB、日本職棒、韓國職棒、NBA、歐洲職籃、中國職籃、NHL冰球、足球、賽馬</td>
                        <td>正規賽：2<br />季後賽：1</td>
                    </tr>
                    <tr>
                        <td>中華職棒、WNBA、韓國職籃</td>
                        <td>正規賽：1.2<br />季後賽：1.2</td>
                    </tr>
                    <tr>
                        <td>俄羅斯冰球、澳洲職棒</td>
                        <td>正規賽：1.5<br />季後賽：1</td>
                    </tr>
                    <tr>
                        <td>NFL美式足球、日本職籃</td>
                        <td>正規賽：3<br />季後賽：1</td>
                    </tr>
                    <tr>
                        <td>澳洲職籃</td>
                        <td>正規賽：1.2<br />季後賽：1</td>
                    </tr>
                </tbody>
            </table>
            <ol>
                <h3>備註：</h3>
                <li><p>若當日沒比賽，則不增加最低注數。</p></li>
                <li><p>若當月場次太少，則由站方自行調整注數限制。</p></li>
                <li><p>季後賽場次較少，本站將視狀況調整最低限制注數。</p></li>
            </ol>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>本賽季戰績的計算範圍？</h2></li>
        <li><p>本賽季戰績分別紀錄您在每個賽季正規賽及季後賽的戰績，熱身賽戰績不予紀錄。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>足球賽季戰績的計算範圍？</h2></li>
        <li><p>我們將足球賽季依年度為單位，計算您在每年 1/1 ~ 12/31的足球預測戰績。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>什麼事蹟才能記入個人榮譽榜？</h2></li>
        <li>
            <p>只要你符合以下條件，系統將會自動幫你將事蹟記入榮譽榜！</p>
            <ol>
                <li><p>當日全壘打４場以上</p></li>
                <li><p>勝率、獲利榜各盤口每週排行榜前三名</p></li>
                <li><p>勝率、獲利榜各盤口每月排行榜前九名</p></li>
                <li><p>勝率、獲利榜各盤口每季排行榜前九名</p></li>
                <li><p>主推獲利、主推總戰績勝率每月排行榜前九名</p></li>
            </ol>
            <br>
            <br>
            <ol>
                <h3>備註：</h3>
                <li><p>注數未滿三注不記入榮譽榜。</p></li>
                <li><p>若勝率榜注數未滿三注 , 獲利榜也不記入榮譽榜。</p></li>
                <li><p>周榮譽榜每週一計算一次 （因賽事場次過少，美式足球與日本職籃不計算周榮譽榜）。</p></li>
            </ol>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>會員需要注意的事項？</h2></li>
        <li>
            <ol>
                <li><p>預測如遇盤分有誤或開盤相關問題，網站有權清除預測或其他處理</p></li>
                <li><p>本站嚴禁開分身、操作兩個以上帳號點選預測，或與他人討論後點選預測意圖成為殺手等行為，如有發現違規帳號，一律依照販售預測規範處理，請務必觀看非常重要的 <a href="/utos.php?tb=3" target="_blank">販售預測規範</a> ，以免您的權益受損。</p></li>
                <li><p>其他更多，請詳閱 <a href="/utos.php" target="_blank">服務條款</a></p></li>
            </ol>
        </li>
    </ul>
</div>
            </div>
            <div id="tab2" class="tab_content">
                <div class="common-article-box">
    <ul class="qa-list">
        <li><h2>當上殺手可以做些什麼？</h2></li>
        <li><p>成為殺手後，可以販售您的預測，賺取現金分潤。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>莊家殺手的評選方式？</h2></li>
        <li>
            <p>
            <ol>
                <li><p>莊家殺手每兩周評選一次，於週一上午11點公佈。</p></li>
                <li>
                    <p>於符合資格的使用者中，依雙周勝率選取前80名做為莊家殺手，勝率相同則依據雙週獲利，若勝率、獲利完全相同，則增額錄取。</p>
                </li>
                <li>
                                            <p>評選資格包含雙周勝率、雙週獲利、最低點選注數等相關標準，可至<a href="/member/login" class="headerLoginButton cboxElement tween" target="_blank">莊家殺手資格頁</a>觀看。
                                        </p>
                </li>
            </ol>
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>單場殺手評選方式？</h2></li>
        <li>
            <p>
            <ol>
                <li><p>單場殺手每個月評選一次，於每月2號上午11點公佈。</p></li>
                <li><p>於符合資格的使用者中，依據主推勝率選取前80名做為單場殺手，勝率相同則依據雙週獲利，若勝率、獲利完全相同，則增額錄取。</p></li>
                <li>
                    <p>
                                                    評選資格包含主推勝率、主推獲利、最低點選注數等相關標準，可至<a href="/member/login" class="headerLoginButton cboxElement tween" target="_blank">單場殺手資格頁</a>觀看。
                                            </p>
                </li>
            </ol>
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>為什麼我都有符合標準，卻沒有當上殺手？</h2></li>
        <li>
            <p>殺手資格頁符合標準，只是代表進入評選的門檻，而殺手是選符合資格中的前80名，若您符合標準卻未選上殺手，代表您的名次排序在80名之後。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>為什麼我的個人頁顯示"此帳號不具被殺手評選資格，預測不公佈"？</h2></li>
        <li><p>若您的個人頁顯示這段文字，代表工友對您操作帳號的行為上有疑慮，工友們會於工作日下午與您電話聯繫，或簡訊告知。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>為什麼我不能開分身點預測、或是跟別人討論預測，來評選殺手？</h2></li>
        <li><p>開分身點預測，或是與他人討論後點預測，會嚴重損害消費者權益，因此本站嚴格禁止此行為，一旦查證將嚴格處理。</p></li>
    </ul>
</div>
            </div>
            <div id="tab3" class="tab_content">
                <div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何才能販售預測呢？</h2></li>
        <li><p>經由評選後，取得莊家殺手或單場殺手資格時，即獲得販售預測的權利。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>擁有販售資格後，要如何販售自己的預測呢?</h2></li>
        <li><p>點選該聯盟的賽事預測後，會出現是否選擇販售的選項，依照畫面指示操作即可。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>我能以何種價格販售我的預測？</h2></li>
        <li>
            <h3>莊家/單場殺手：</h3>
            <p> 莊家/單場殺手販售預測，原價為噱幣99，特價時則為噱幣79元。 </p>
            <br>
            <h3>雙重殺手：</h3>
            <p>雙重殺手販售預測，原價為噱幣168，特價時則為噱幣148元。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2> 如何判定雙重殺手的販售資格？</h2></li>
        <li>
            <p>雙重殺手定義為該聯盟的單一盤口，同時具備莊家殺手及單場殺手資格者。</p>
            <p>例如NBA的運彩盤同時為莊家殺手及單場殺手，則成為雙重殺手；若NBA的運彩盤為莊家殺手，國際盤為單場殺手，則不為雙重殺手。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>販售預測能獲取多少利潤？</h2></li>
        <li>
            <p>您可以獲取販售預測金額的45%，金額計算到小數點第一位，四捨五入。累積滿新台幣 1000 元整即可請款。 </p>
            <p>
                您可至「<a href="/member/login"  class="headerLoginButton cboxElement tween" target="_blank">帳戶</a>」查看您賺取的總額，並且申請匯出現金至您指定的銀行帳戶。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>販售預測之後，可以更改預測嗎？</h2></li>
        <li>
            <p>為保護付費者的權益，您在開始販售預測後，只可以新增預測，不可以更改、刪除預測。</p>
            <p>*美洲賽事在第一場賽事開打後，即不能新增預測。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>殺手可以到討論區張貼預測嗎？</h2></li>
        <li>
            <h3>莊家殺手：</h3>
            <p>莊家殺手選擇販售預測的話，不得將超過一半的內容公開在站上可輸入文字的地方，但可公佈部分預測作為行銷宣傳之用。</p>
            <br>
            <h3>單場殺手</h3>
            <p>單場殺手選擇販售預測的話，不得將主推內容公開在站上可輸入文字的地方，但可公佈非主推預測作為行銷宣傳之用。</p>
            <br>
            <h3>雙重殺手</h3>
            <p>雙重殺手比照上述兩項規範，不得公開超過一半以及不得公開主推在站上可輸入文字的地方，但可公佈部分預測作為行銷宣傳之用。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何得知自己每天的收入明細呢?</h2></li>
        <li>
            <p>
                我們會在「開賽日隔天下午」派發分潤所得到您在玩運彩的現金帳戶，以及寄送收入明細給您，您可以在「<a href="/member/login"  class="headerLoginButton cboxElement tween" target="_blank">帳戶</a>」頁中的信箱查看。
                例如您販售 1/26 的賽事預測，將會於 1/27 18:00 前收到 1/26 賽事預測所獲取的分潤所得明細。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>在什麼情況下會將噱幣退還給消費者?</h2></li>
        <li>
            <h3>莊家/雙重殺手：</h3>
            <p>只要您在網站上販售的預測賽事全部未開賽，我們會將您當次販售所得退還給消費者，以維護消費者權益。</p>
            <br>
            <h3>單場殺手：</h3>
            <p>只要您在網站上販售的主推未開賽，我們會將您當次販售所得退還給消費者，以維護消費者權益。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>每期的莊家/單場殺手可以販售幾天預測呢？</h2></li>
        <li>
            <h3>莊家殺手：</h3>
            <p>莊家殺手可以販售28天的預測。倘若蟬連成功，以新當選的日期，往後算28天為販售期限。</p>
            <br>
            <h3>單場殺手</h3>
            <p>單場殺手可以販售一個月的預測。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>販售預測時，我可以有什麼宣傳機會？</h2></li>
        <li>
            <p>
                您可以利用說明文宣傳自己，也可以到討論區多發文、多與其他使用者互動，來提高自己的曝光度。若您戰績優異，站方也會不定時在站上廣告位置宣傳。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>我賺的現金分潤，可以直接換成噱幣嗎？</h2></li>
        <li><p>由於法律上的規定，殺手賺取的現金分潤無法直接轉換為噱幣，僅能由殺手提領後自行運用。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>殺手一定要知道的規範？</h2></li>
        <li><p>本站嚴禁開分身、操作兩個以上帳號點選/販售預測，或與他人討論後點選預測意圖成為殺手等行為，其他更多規範，請務必觀看非常重要的 <a href="/utos.php?tb=3" target="_blank">販售預測規範</a> ，以免您的權益受損。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>為什麼我被禁售了？</h2></li>
        <li><p>若您被禁止販售，可能是您在宣傳上有廣告不實的地方，或有其他違反規定的行為，若有疑慮，請用「<a href="contact.php">聯絡我們</a>」，或撥打客服電話07-9700123。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>從哪裡看到我現在賺了多少分潤？</h2></li>
        <li><p>網頁上方有顯示您的暱稱，點選暱稱後，進入下方選單中的「<a href="/member/login"  class="headerLoginButton cboxElement tween" target="_blank">帳戶</a>」，即可看見您目前所賺取的分潤。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>說明文、殺手小叮嚀的使用規則</h2></li>
        <li>
            <p>殺手可使用說明文宣傳自己，會於購牌區及個人頁顯示；殺手小叮嚀則是撰寫給消費者看的購牌叮嚀或小分析。</p>
            <p>使用規則：文字皆不得違反版規、不得宣傳其他聯盟、不可張貼地下注單。</p>
        </li>
    </ul>
</div>
            </div>
            <div id="tab4" class="tab_content">
                <div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買殺手的預測，可以看幾場的比賽呢？</h2></li>
        <li><p>凡購買殺手的預測，當天該殺手所有的預測，您都可以看到。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買預測的價格是多少呢？</h2></li>
        <li>
            <h3>莊家/單場殺手：</h3>
            <p>莊家/單場殺手原價販售時為噱幣99元，特價時則為噱幣79元。</p>
            <br>
            <h3>雙重殺手：</h3>
            <p>雙重殺手原價販售時為噱幣168元，特價時則為噱幣148元。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買殺手後，他新增的預測我知道嗎？</h2></li>
        <li><p>購買後，若殺手新增預測或更新殺手小叮嚀，網頁右上方的「購牌清單」會顯示通知。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買殺手預測如遇未開賽或延賽會退費嗎？</h2></li>
        <li>
            <h3>莊家/雙重殺手：</h3>
            <p>只要您購買的賽事預測全部未開賽，我們會在開賽日的隔天下午，退回您消費的噱幣或兌換券。</p>
            <br>
            <h3>單場殺手：</h3>
            <p>只要您購買的主推未開賽，我們會在開賽日的隔天下午，退回您消費的噱幣或兌換券。</p>
            <br>
            <h3>備註：</h3>
            <p>如是運彩公司公告為無效賽事的比賽，則不在未開賽退費規範中。</p>
            <p>一律於「開賽日隔天下午」退幣/券。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買的預測不準時，有什麼補償機制呢？</h2></li>
        <li>
            <h3>莊家殺手：</h3>
            <p>若您購買莊家殺手的預測，當日預測勝率未達五成，我們會在開賽日隔天下午，補償您一張免費看預測兌換券。</p>
            <p>*當日賠率低於1.4的比賽，不列入預測勝率的計算。</P>
            <br>
            <h3>單場殺手：</h3>
            <p>若您購買單場殺手的預測，當日主推未過，我們會在開賽日隔天下午，補償您一張免費看預測兌換券。</p>
            <br>
            <h3>雙重殺手：</h3>
            <p>
            若您購買雙重殺手的預測，主推未過或是勝率未達五成，皆會在開賽日隔天下午，補償您一張免費看預測兌換券，若同時兩個標準都未達到，將補償您兩張免費看預測兌換卷。
            </p>
            <p>*當日賠率低於1.4的比賽，不列入預測勝率的計算。</p>
            <br>
            <h3>備註：</h3><p>兌換券於「開賽日隔天下午」派送。</strong></p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>什麼是免費看預測兌換券？</h2></li>
        <li><p>一張免費看預測兌換卷，可以讓您免費觀看一次莊家/單場殺手的預測兌換券沒有時間，球類、盤別的限制，且可用來觀看所有殺手預測；唯觀看雙重殺手預測時，必須使用兩張兌換券。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>使用兌換卷看殺手預測，若勝率不符規定，是否又可以再換取一張兌換卷呢？</h2></li>
        <li><p>不行，兌換券不適用於補償機制。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>各種殺手販售的預測有什麼不同？</h2></li>
        <li>
            <h3>莊家殺手：</h3>
            <p>莊家殺手的預測適合均注跟牌，因此若該莊家殺手推薦4場預測，4場預測您皆可以斟酌參考。</p>
            <br>
            <h3>單場殺手：</h3>
            <p>單場殺手的預測適合重點投注，每日一注主推，因此購買後建議只參考主推那支預測。</p>
            <br>
            <h3>雙重殺手：</h3>
            <p>是於單一盤口同時具備莊家殺手及單場殺手兩種販售資格，此種殺手的預測可以全數斟酌參考。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何挑選適合自己的殺手?</h2></li>
        <li><p>首先依照您下注的管道挑選「國際盤」或是「運彩盤」的殺手，再依照您每日投注習慣，若您平時每日投注3注以上，建議您選購莊家殺手；若您平時每日投注1~2注，建議您選購單場殺手。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何知道補/退卷了沒？</h2></li>
        <li><p>系統完成補/退券後，網頁右上方「購牌清單」會顯示通知。</p></li>
    </ul>
</div>
            </div>
            <div id="tab5" class="tab_content">
                 <div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何購買噱幣？</h2></li>
        <li><p>您可在登入後，到 <a href="buy_pcash.php">購買噱幣頁</a> 購買。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>購買噱幣的付款方式有哪些呢？</h2></li>
        <li>
            <h3>我們提供以下付款方式：</h3>
            <ol class="common-liststyle">
                <li><p>ATM匯款</p></li>
                <li><p>信用卡</p></li>
                <li><p>超商繳費 7-11 ibon / 全家 FamiPort / 萊爾富 Life-ET / OK超商 OKGO</p></li>
                <li><p>LINE PAY</p></li>
                <li><p>手機小額付款</p></li>
                <li><p>Paypal</p></li>
            </ol>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>噱幣可以轉讓給其他版友嗎？</h2></li>
        <li><p>本站不提供這項服務。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>噱幣購買後可否退費?</h2></li>
        <li><p>若整筆訂單（噱幣、兌換券）未使用可退費，一經使用，即無法退費。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>噱幣有使用期限及時間的限制嗎？</h2></li>
        <li><p>沒有。在任何的時間點，您都可以使用噱幣進行消費行為。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>採用小額付費或LINE PAY付款，發票由誰開立?</h2></li>
        <li>
            <p>若是使用手機小額付款，會與您的電信帳單合併開立。若是使用LINE PAY付款，會由 imoney 統振股份有限公司開立。</p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>玩運彩如何開立發票?(針對非小額付款付費方式)</h2></li>
        <li>
            <p>
                玩運彩經財政部高雄市國稅局於中華民國100年7月28日， 發文(發文字號:財高國稅鎮營業字第1000011276號)核准玩運彩與非營業人交易使用電子發票。 在您購買完成後的兩個工作日內您可以在帳戶信箱內看見您購買的噱幣已開立電子發票，點選之後便可看到購買日期，購買金額，發票號碼資料。 另外，玩運彩也會將發票資料上傳到財政部電子發票整合服務平台留存。
            </p>
        </li>
        <li>
            <p>
                若二聯式發票有『銷貨退回或折讓證明單』之需求時，不必寄回發票，在租戶申請紙本發票時，即已同意由摩爾空間代為處理銷貨退回或折讓證明單，以利加速退款作業處理，屆時摩爾空間將直接開立折讓單上傳至財政部電子發票整合服務平台。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>玩運彩會如何處理中獎發票?</h2></li>
        <li>
            <p>
                收到中獎發票簡訊後煩請上玩運彩網站並登入會員，請您點擊彈跳視窗填寫資料，內容須請您提供收件姓名、電話、地址，待填寫完畢後送出後，工友會再統一寄出。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>如何索取紙本發票?</h2></li>
        <li>
            <p>
                如您有需要索取紙本發票，請使用 「<a href="contact.php">聯絡我們</a>」 或是撥打客服電話07-9700123索取紙本發票。請您詳細告知您的姓名，發票寄件地址，
                以及購買日期，我們將會於14日內將發票寄出給您。
            </p>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>需要開立三聯式發票(有打統編、抬頭者)該如何做?</h2></li>
        <li><p>請於購買完成1日內使用 「<a href="contact.php">聯絡我們</a>」 告知統編、抬頭跟發票寄送地址，玩運彩會於14日內將三聯式發票寄出給您。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>電子發票是甚麼?使用電子發票的好處?</h2></li>
        <li>
            <p>電子發票之效力與實體發票相同，且有下列好處，為響應環保，請多多使用，減少紙本發票的索取。</p>
            <ol class="common-liststyle">
              <li>系統將會自動為您核對中獎，中獎後會立即寄送發票給您兌換獎金。</li>
              <li>系統會為您保留消費資料。</li>
              <li>退貨時，不用寄送發票來作廢，系統可自動處理，退款可加速完成。</li>
            </ol>
        </li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>我用了兩個帳號買噱幣，可不可以合併在一起？</h2></li>
        <li><p>很抱歉，不同帳號的噱幣無法合併在一起。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>我已經儲值成功了，噱幣怎麼還沒派給我？</h2></li>
        <li><p>確認儲值成功後10~15分鐘噱幣將會自動入帳，若超過15分鐘尚未收到噱幣，請使用網頁下方「<a href="contact.php">聯絡我們</a>」告知，或撥打客服電話07-9700123，我們會盡速為您處理。</p></li>
    </ul>
</div>

<div class="common-article-box">
    <ul class="qa-list">
        <li><h2>從哪裡可以看到我剩多少噱幣？</h2></li>
        <li><p>網頁上方有顯示您的暱稱，點選暱稱後，進入下方選單中的「<a href="/member/login"  class="headerLoginButton cboxElement tween" target="_blank">帳戶</a>」，即可看見您剩餘的噱幣及兌換券。</p></li>
    </ul>
</div>
            </div>
        </div>
    </div>
</div>
<!--常見問題 修改 end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<!--TAB JS START-->
<script type="text/javascript">
    $(function(){
                    var _showTab = 0;
                $('.common-tabs').each(function(){
            var $tab = $(this);
            $('ul.tabs li', $tab).eq(_showTab).addClass('active');
            $('.tab_content', $tab).hide().eq(_showTab).show();
            $('ul.tabs li', $tab).click(function() {
                var $this = $(this),
                    _clickTab = $this.find('a').attr('href');
                $this.addClass('active').siblings('.active').removeClass('active');
                $(_clickTab).stop(false, true).fadeIn().siblings().hide();
                return false;
            }).find('a').focus(function(){
                this.blur();
            });
        });
    });
</script>
<!--TAB JS END-->
                                                                </div>
                </div>
            </div>
                        <div class="footerbox-whole">
                <div class="footerbox">


                    <!-- ==================== #8380 加大手機版footer ==================== -->

                                            <!-- 電腦版 -->
                        <ul class="footerhint">
                            <div class="service_time">09:30~24:00</div><!--新增時間-->
                                                        <li><strong class="service_phone">客服電話</strong><span>07-9700123</span></li><!--新增時間-->
                            <li><a href="/contact.php?back=L3FhLnBocA">聯絡我們</a></li>
                            <li><a href="/qa.php">常見問題</a></li>
                            <li><a href="/utos.php">服務條款</a></li>
                        </ul>
                        <div class="footernav">
                            <ul>
                                <li><a href="/aboutus.php">關於我們</a></li>
                            </ul>
                        </div>
                                            

                    
                    <!-- ==================== #8380 加大手機版footer ==================== -->


                    <p class="copyrights">&copy; 2025 玩運彩 <span>法律顧問：漢英得力法律事務所 陳鎮宏律師</span>
                                                                </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                    <p class="recaptcha">
                        This site is protected by reCAPTCHA and the Google <a class="recaptcha__link" href="https://policies.google.com/privacy">Privacy Policy</a> and <a class="recaptcha__link" href="https://policies.google.com/terms">Terms of Service</a> apply.
                    </p>
                    <!-- ========== reCAPTCHA服務的宣告說明 ========== -->
                </div>
                <!-- Trademark -->
                            </div>
                    </div>
                		<script type="text/javascript">
		if ( top.location !== self.location ) {
			top.location=self.location;
		}
        $(function() {
            $('#navi .carditem').on('click', function () {
                // 紀錄使用者有補卷通知時點擊購牌清單的動作
                if ($("#js-coupon-issued").length > 0) {
                    $.post('/user_actions.php?action=setEvent', {name: 'ShoppingListDropdownMenuBTN'});
                }
            });
            $('.js-promotion_event').on('click', function () {
                // 版標特別要加events或ga
                if ($(this).data('events') != '') {
                    PLS.sentEvent($(this).data('events'));
                }
                if ($(this).data('categroy') != '' && $(this).data('lable') != '') {
                    PLS.sentGaEvent($(this).data('categroy'), 'click', $(this).data('lable'));
                }
            });
        })
		</script>
                                                <script>
                    </script>
                    <script>
                ga('send', 'pageview');
            </script>
                    </body>
</html>
